#!/usr/bin/env python3
"""
Script to extract best results from grid search experiments based on time for specific recall cuts.
"""

import os
import pandas as pd
import shutil
from pathlib import Path
import glob
import argparse

def main():
    # Parse command-line arguments
    parser = argparse.ArgumentParser(
        description='Extract best results from grid search experiments based on time for specific recall cuts.'
    )
    parser.add_argument(
        'grid_search_dir',
        type=str,
        help='Path to the grid search directory containing building_combination_* folders'
    )
    parser.add_argument(
        'best_results_dir',
        type=str,
        help='Path to the output directory where best results will be saved'
    )
    parser.add_argument(
        '--recall-cuts',
        type=float,
        nargs='+',
        default=[0.9, 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99],
        help='Target recall cuts (default: 0.9 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98 0.99)'
    )
    
    args = parser.parse_args()
    
    # Define paths from arguments
    grid_search_dir = args.grid_search_dir
    best_results_dir = args.best_results_dir
    
    # Target recall cuts
    recall_cuts = args.recall_cuts
    
    # Create best_results directory if it doesn't exist
    os.makedirs(best_results_dir, exist_ok=True)
    
    # Initialize list to store best results
    best_results = []
    
    # Dictionary to store best result info for each recall cut (for copying result files)
    best_result_files = {}
    
    print("Processing grid search results...")
    
    # Get all building combination folders
    building_folders = glob.glob(os.path.join(grid_search_dir, "building_combination_*_*"))
    
    if not building_folders:
        print("No building combination folders found!")
        return
    
    print(f"Found {len(building_folders)} building combination folders")
    
    # Process each recall cut
    for recall_cut in recall_cuts:
        print(f"\nProcessing recall cut: {recall_cut}")
        best_time = float('inf')
        best_result = None
        best_folder = None
        best_combination = None
        
        # Check each building folder
        for folder in building_folders:
            report_path = os.path.join(folder, "report.tsv")
            
            if not os.path.exists(report_path):
                print(f"Warning: No report.tsv found in {folder}")
                continue
            
            try:
                # Read the report
                df = pd.read_csv(report_path, sep='\t')
                
                # Filter results by recall cut (with some tolerance for floating point comparison)
                tolerance = 0.001
                filtered_df = df[df['Recall'] >= (recall_cut - tolerance)]
                
                if filtered_df.empty:
                    continue
                
                # Find the result with minimum time for this recall cut
                min_time_idx = filtered_df['Query Time (microsecs)'].idxmin()
                min_time_row = filtered_df.loc[min_time_idx]
                
                query_time = min_time_row['Query Time (microsecs)']
                
                # Check if this is the best (lowest) time so far
                if query_time < best_time:
                    best_time = query_time
                    best_result = {
                        'recall_cut': recall_cut,
                        'time': query_time,
                        'mrr': min_time_row['RR@10'],
                        'actual_recall': min_time_row['Recall'],
                        'combination': min_time_row['Subsection']
                    }
                    best_folder = folder
                    best_combination = min_time_row['Subsection']
                    
            except Exception as e:
                print(f"Error processing {folder}: {e}")
                continue
        
        if best_result:
            best_results.append(best_result)
            best_result_files[recall_cut] = {
                'folder': best_folder,
                'combination': best_combination
            }
            print(f"Best result for recall {recall_cut}: {best_time} microsecs from {best_combination} in {os.path.basename(best_folder)}")
        else:
            print(f"No results found for recall cut {recall_cut}")
    
    # Create DataFrame and save to TSV
    if best_results:
        results_df = pd.DataFrame(best_results)
        
        # Reorder columns for output
        output_df = results_df[['recall_cut', 'time', 'mrr']].copy()
        output_df.columns = ['recall_cut', 'time', 'mrr']
        
        # Save to TSV
        output_path = os.path.join(best_results_dir, "report_best.tsv")
        output_df.to_csv(output_path, sep='\t', index=False)
        print(f"\nBest results saved to: {output_path}")
        
        # Copy corresponding result files
        print("\nCopying best result files...")
        for recall_cut, info in best_result_files.items():
            folder = info['folder']
            combination = info['combination']
            
            # Extract combination number from combination name (e.g., "combination_1" -> "1")
            try:
                combination_num = combination.split('_')[1]
                source_file = os.path.join(folder, f"results_{combination}")
                
                if os.path.exists(source_file):
                    # Create target filename with recall cut info
                    target_file = os.path.join(best_results_dir, f"results_recall_{recall_cut}_{combination}")
                    shutil.copy2(source_file, target_file)
                    print(f"Copied {source_file} -> {target_file}")
                else:
                    print(f"Warning: Source file not found: {source_file}")
            except Exception as e:
                print(f"Error copying result file for recall {recall_cut}: {e}")
        
        print(f"\nProcessing complete! Found best results for {len(best_results)} recall cuts.")
        print("\nSummary of best results:")
        print(output_df.to_string(index=False))
    else:
        print("No results found!")

if __name__ == "__main__":
    main()