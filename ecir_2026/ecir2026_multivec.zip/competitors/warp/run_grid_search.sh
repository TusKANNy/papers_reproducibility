#!/bin/bash
# Grid search completa per LoTTE e MS MARCO con valori multipli di ncells

set -e  # Exit on error

echo "=========================================="
echo "GRID SEARCH - LoTTE + MS MARCO"
echo "=========================================="
echo ""

# Base paths - MODIFY THESE TO MATCH YOUR SETUP
LOTTE_BASE="" # Path to LoTTE data folder (downloaded from HF)
MSMARCO_BASE="" # Path to MS MARCO data folder (downloaded from HF)

# Validate paths are set
if [ -z "$LOTTE_BASE" ] || [ -z "$MSMARCO_BASE" ]; then
    echo "Error: Please set LOTTE_BASE and MSMARCO_BASE paths in this script before running."
    echo "Edit lines 12-13 with the paths to your downloaded WARP datasets."
    exit 1
fi

# Create results directory if it doesn't exist
mkdir -p results

# Parametri comuni
CHECKPOINT="colbert-ir/colbertv2.0"
NCELLS="1,2"

# Base paths - MODIFY THESE TO MATCH YOUR SETUP
LOTTE_BASE="" # Path to LoTTE data folder (downloaded from HF)
MSMARCO_BASE="" # Path to MS MARCO data folder (downloaded from HF)

# LoTTE paths (derived from base)
LOTTE_INDEX="${LOTTE_BASE}/index_files"
LOTTE_QUERIES="${LOTTE_BASE}/questions.search.tsv"
LOTTE_QRELS="${LOTTE_BASE}/qas.search.jsonl"
LOTTE_COLLECTION="${LOTTE_BASE}/collection.tsv"
LOTTE_OUTPUT="results/lotte_grid_search_full.json"

# MS MARCO paths (derived from base)
MSMARCO_INDEX="${MSMARCO_BASE}/index_files"
MSMARCO_QUERIES="${MSMARCO_BASE}/queries.dev.small.tsv"
MSMARCO_QRELS="${MSMARCO_BASE}/qrels.dev.small.jsonl"
MSMARCO_COLLECTION="${MSMARCO_BASE}/collection.tsv"
MSMARCO_OUTPUT="results/msmarco_grid_search_full.json"

echo "=========================================="
echo "1. Grid Search LoTTE"
echo "=========================================="
echo "Index: $LOTTE_INDEX"
echo "Queries: $LOTTE_QUERIES"
echo "Qrels: $LOTTE_QRELS"
echo "Collection: $LOTTE_COLLECTION"
echo "ncells: $NCELLS"
echo "Output: $LOTTE_OUTPUT"
echo ""

python grid_search.py \
    --checkpoint "$CHECKPOINT" \
    --index-root "$LOTTE_INDEX" \
    --queries "$LOTTE_QUERIES" \
    --qrels "$LOTTE_QRELS" \
    --collection "$LOTTE_COLLECTION" \
    --ncells "$NCELLS" \
    --k 10 \
    --metric success \
    --output "$LOTTE_OUTPUT"

echo ""
echo "✅ Completed grid search on LoTTE!"
echo ""
echo "=========================================="
echo "2. Grid Search MS MARCO"
echo "=========================================="
echo "Index: $MSMARCO_INDEX"
echo "Queries: $MSMARCO_QUERIES"
echo "Qrels: $MSMARCO_QRELS"
echo "Collection: $MSMARCO_COLLECTION"
echo "ncells: $NCELLS"
echo "Output: $MSMARCO_OUTPUT"
echo ""

python grid_search.py \
    --checkpoint "$CHECKPOINT" \
    --index-root "$MSMARCO_INDEX" \
    --queries "$MSMARCO_QUERIES" \
    --qrels "$MSMARCO_QRELS" \
    --collection "$MSMARCO_COLLECTION" \
    --ncells "$NCELLS" \
    --k 10 \
    --metric mrr \
    --output "$MSMARCO_OUTPUT"

echo ""
echo "✅ Completed grid search on MS MARCO!"
echo ""
echo "=========================================="
echo "GRID SEARCH COMPLETED!"
echo "=========================================="
echo "Results saved in:"
echo "  - $LOTTE_OUTPUT"
echo "  - $MSMARCO_OUTPUT"
echo ""
