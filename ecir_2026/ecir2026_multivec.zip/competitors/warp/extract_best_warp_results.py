#!/usr/bin/env python3
"""
Extract best (fastest) WARP configurations for specific metric cuts.

This script parses WARP grid search results and identifies the configuration
with minimal query time for each specified metric threshold (e.g., MRR@10 or Success@5).

Usage:
    # For MS MARCO (MRR@10)
    python extract_best_warp_results.py \
        --input results/msmarco_grid_search_full.json \
        --output results/msmarco_best_results.tsv \
        --metric MRR@10 \
        --cuts 0.39 0.392 0.394 0.396 0.398 0.399 0.4 0.402

    # For LoTTE (Success@5)
    python extract_best_warp_results.py \
        --input results/lotte_grid_search_full.json \
        --output results/lotte_best_results.tsv \
        --metric Success@5 \
        --cuts 0.67 0.675 0.68 0.685 0.69 0.695 0.70 0.705
"""

import json
import argparse
from typing import List, Dict, Tuple
import sys


def load_grid_search_results(input_path: str) -> Dict:
    """Load grid search results from JSON file."""
    try:
        with open(input_path, 'r') as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        print(f"Error: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in input file: {e}", file=sys.stderr)
        sys.exit(1)


def extract_best_for_cuts(
    results: Dict,
    metric_name: str,
    cuts: List[float],
    tolerance: float = 1e-6
) -> List[Dict]:
    """
    Extract the fastest configuration for each metric cut.
    
    Args:
        results: Grid search results dictionary or list
        metric_name: Name of the metric to filter by (e.g., "MRR@10", "Success@5")
        cuts: List of metric thresholds to find best configurations for
        tolerance: Tolerance for floating point comparison
        
    Returns:
        List of dictionaries, one for each cut with best configuration
    """
    # Handle both dictionary with "results" key and direct list
    if isinstance(results, dict):
        if "results" not in results:
            print(f"Error: Invalid results format. Expected 'results' key or a list.", file=sys.stderr)
            sys.exit(1)
        grid_results = results["results"]
    elif isinstance(results, list):
        grid_results = results
    else:
        print(f"Error: Invalid results format. Expected dictionary or list.", file=sys.stderr)
        sys.exit(1)
    best_configs = []
    
    for cut in cuts:
        # Find all configurations that meet or exceed the metric threshold
        candidates = []
        for result in grid_results:
            # Handle both nested structure (metrics dict) and flat structure
            if "metrics" in result:
                if metric_name not in result["metrics"]:
                    continue
                metric_value = result["metrics"][metric_name]
            elif metric_name in result:
                metric_value = result[metric_name]
            else:
                continue
            
            # For percentage metrics (Success@5), normalize if needed
            if metric_name.startswith("Success") and cut < 1.0:
                # cut is given as 0.67, but metric might be stored as 67.0
                cut_normalized = cut * 100
            else:
                cut_normalized = cut
            
            # Check if metric meets threshold
            if metric_value >= cut_normalized - tolerance:
                # Handle both nested timings and flat structure
                if "timings" in result:
                    avg_latency = result["timings"]["avg_latency_ms"]
                    p50_latency = result["timings"]["p50_latency_ms"]
                    p95_latency = result["timings"]["p95_latency_ms"]
                    p99_latency = result["timings"]["p99_latency_ms"]
                else:
                    # Flat structure with different field names
                    avg_latency = result.get("retrieval_latency_avg_ms", result.get("avg_latency_ms"))
                    p50_latency = result.get("retrieval_latency_p50_ms", result.get("p50_latency_ms"))
                    p95_latency = result.get("retrieval_latency_p95_ms", result.get("p95_latency_ms"))
                    p99_latency = result.get("retrieval_latency_p99_ms", result.get("p99_latency_ms"))
                
                candidates.append({
                    "ncells": result["ncells"],
                    "metric_value": metric_value,
                    "avg_latency_ms": avg_latency,
                    "p50_latency_ms": p50_latency,
                    "p95_latency_ms": p95_latency,
                    "p99_latency_ms": p99_latency,
                })
        
        if not candidates:
            print(f"Warning: No configurations found for {metric_name} >= {cut}", file=sys.stderr)
            best_configs.append({
                "cut": cut,
                "ncells": None,
                "metric_value": None,
                "avg_latency_ms": None,
                "p50_latency_ms": None,
                "p95_latency_ms": None,
                "p99_latency_ms": None,
                "status": "NOT_FOUND"
            })
            continue
        
        # Find the fastest configuration (minimum average latency)
        best = min(candidates, key=lambda x: x["avg_latency_ms"])
        best_configs.append({
            "cut": cut,
            "ncells": best["ncells"],
            "metric_value": best["metric_value"],
            "avg_latency_ms": best["avg_latency_ms"],
            "p50_latency_ms": best["p50_latency_ms"],
            "p95_latency_ms": best["p95_latency_ms"],
            "p99_latency_ms": best["p99_latency_ms"],
            "status": "OK"
        })
    
    return best_configs


def save_results_tsv(best_configs: List[Dict], output_path: str, metric_name: str):
    """Save best configurations to TSV file."""
    with open(output_path, 'w') as f:
        # Write header
        f.write(f"cut\tncells\t{metric_name}\tavg_latency_ms\tp50_latency_ms\tp95_latency_ms\tp99_latency_ms\tstatus\n")
        
        # Write data
        for config in best_configs:
            cut = config["cut"]
            ncells = config["ncells"] if config["ncells"] is not None else "N/A"
            metric_value = f"{config['metric_value']:.4f}" if config["metric_value"] is not None else "N/A"
            avg_lat = f"{config['avg_latency_ms']:.4f}" if config["avg_latency_ms"] is not None else "N/A"
            p50_lat = f"{config['p50_latency_ms']:.4f}" if config["p50_latency_ms"] is not None else "N/A"
            p95_lat = f"{config['p95_latency_ms']:.4f}" if config["p95_latency_ms"] is not None else "N/A"
            p99_lat = f"{config['p99_latency_ms']:.4f}" if config["p99_latency_ms"] is not None else "N/A"
            status = config["status"]
            
            f.write(f"{cut}\t{ncells}\t{metric_value}\t{avg_lat}\t{p50_lat}\t{p95_lat}\t{p99_lat}\t{status}\n")


def print_summary(best_configs: List[Dict], metric_name: str):
    """Print a summary of the best configurations."""
    print("\n" + "=" * 80)
    print(f"BEST CONFIGURATIONS FOR {metric_name}")
    print("=" * 80)
    print(f"{'Cut':<8} {'ncells':<8} {metric_name:<12} {'Avg Latency (ms)':<18} {'Status':<10}")
    print("-" * 80)
    
    for config in best_configs:
        cut = f"{config['cut']:.3f}"
        ncells = str(config["ncells"]) if config["ncells"] is not None else "N/A"
        metric_value = f"{config['metric_value']:.4f}" if config["metric_value"] is not None else "N/A"
        avg_lat = f"{config['avg_latency_ms']:.4f}" if config["avg_latency_ms"] is not None else "N/A"
        status = config["status"]
        
        print(f"{cut:<8} {ncells:<8} {metric_value:<12} {avg_lat:<18} {status:<10}")
    
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser(
        description="Extract best WARP configurations for specific metric cuts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Path to grid search results JSON file"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        required=True,
        help="Path to output TSV file"
    )
    
    parser.add_argument(
        "--metric",
        type=str,
        required=True,
        help="Metric name to filter by (e.g., 'MRR@10', 'Success@5')"
    )
    
    parser.add_argument(
        "--cuts",
        type=float,
        nargs='+',
        required=True,
        help="List of metric thresholds to extract best configs for"
    )
    
    parser.add_argument(
        "--tolerance",
        type=float,
        default=1e-6,
        help="Tolerance for floating point comparison (default: 1e-6)"
    )
    
    args = parser.parse_args()
    
    # Load results
    print(f"Loading grid search results from: {args.input}")
    results = load_grid_search_results(args.input)
    
    # Extract best configurations
    print(f"Extracting best configurations for {args.metric} at cuts: {args.cuts}")
    best_configs = extract_best_for_cuts(
        results,
        args.metric,
        args.cuts,
        args.tolerance
    )
    
    # Save to TSV
    print(f"Saving results to: {args.output}")
    save_results_tsv(best_configs, args.output, args.metric)
    
    # Print summary
    print_summary(best_configs, args.metric)
    
    print(f"\n✅ Done! Results saved to: {args.output}")


if __name__ == "__main__":
    main()
