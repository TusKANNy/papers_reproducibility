#!/usr/bin/env python3
"""
Grid search for WARP retrieval parameters with separate encoding and retrieval timing.
Measures only retrieval latency (excluding query encoding) and evaluates metrics at different cutoffs.
"""

import os
import time
import argparse
import json
from collections import defaultdict
from dotenv import load_dotenv

# FORCE SINGLE-THREADED EXECUTION FOR ACCURATE TIMING
# Set these BEFORE importing torch/numpy to avoid hidden parallelism
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["OMP_WAIT_POLICY"] = "PASSIVE"
os.environ["KMP_AFFINITY"] = "disabled"

load_dotenv()

import torch
import pytrec_eval

# Set PyTorch to single thread after import
torch.set_num_threads(1)

from warp.infra import Run, RunConfig
from warp.infra.config import ColBERTConfig
from warp.searcher import Searcher
from warp.data.queries import Queries
from warp.data.ranking import Ranking


def load_qrels_lotte(qrels_path):
    """Load LoTTE qrels (answer PIDs for each query) from JSONL format"""
    import json
    qrels = {}
    with open(qrels_path, 'r') as f:
        for line in f:
            qa = json.loads(line)
            qid = qa['qid']
            answer_pids = qa['answer_pids']
            qrels[qid] = set(answer_pids)
    return qrels


def load_qrels_msmarco(qrels_path):
    """Load MS MARCO qrels from JSONL format for pytrec_eval"""
    import json
    qrels = {}
    with open(qrels_path, 'r') as f:
        for line in f:
            qa = json.loads(line)
            qid = str(qa['qid'])  # pytrec_eval requires string keys
            answer_pids = qa['answer_pids']
            # pytrec_eval format: {qid: {docid: relevance}}
            qrels[qid] = {str(pid): 1 for pid in answer_pids}
    return qrels


def load_queries_tsv(queries_path):
    """Load queries from TSV file"""
    queries = {}
    with open(queries_path, 'r') as f:
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) >= 2:
                qid = int(parts[0])
                query_text = parts[1]
                queries[qid] = query_text
    return queries


def calculate_success_at_k(qrels, rankings, k):
    """Calculate Success@k metric for LoTTE"""
    success_count = 0
    total_queries = 0
    
    for qid, answer_pids in qrels.items():
        if qid not in rankings:
            continue
        total_queries += 1
        # Get top-k PIDs from rankings
        top_k_pids = set([pid for pid, rank, score in rankings[qid][:k]])
        # Check if any answer PID is in top-k
        if len(answer_pids & top_k_pids) > 0:
            success_count += 1
    
    return (success_count / total_queries * 100) if total_queries > 0 else 0.0


def calculate_metrics_with_pytrec(qrels, rankings, k_values=[10]):
    """
    Calculate IR metrics using pytrec_eval for MS MARCO.
    
    Args:
        qrels: Dict in pytrec_eval format {qid: {docid: relevance}}
        rankings: Dict {qid: [(pid, rank, score), ...]}
        k_values: List of k values to evaluate at
        
    Returns:
        Dict with metrics: recip_rank (MRR), map_cut, ndcg_cut, recall
    """
    # Convert rankings to pytrec_eval format: {qid: {docid: score}}
    run = {}
    for qid, results in rankings.items():
        qid_str = str(qid)
        if qid_str not in qrels:
            continue
        run[qid_str] = {str(pid): score for pid, rank, score in results}
    
    # Define metrics to calculate
    metrics_to_calc = ['recip_rank']  # MRR
    for k in k_values:
        metrics_to_calc.append(f'map_cut.{k}')
        metrics_to_calc.append(f'ndcg_cut.{k}')
        metrics_to_calc.append(f'recall.{k}')
    
    # Calculate metrics
    evaluator = pytrec_eval.RelevanceEvaluator(qrels, metrics_to_calc)
    results = evaluator.evaluate(run)
    
    # Aggregate results across queries
    aggregated = {}
    for metric in metrics_to_calc:
        # pytrec_eval returns metrics with underscores: map_cut_10, ndcg_cut_10, etc.
        metric_internal = metric.replace('.', '_')
        metric_key = metric.replace('.', '@') if '.' in metric else metric
        if metric == 'recip_rank':
            metric_key = 'MRR@10'  # Standard name for MRR@10
        aggregated[metric_key] = sum(results[qid][metric_internal] for qid in results) / len(results)
    
    return aggregated


def grid_search_retrieval(
    checkpoint,
    index_name,
    queries_path,
    qrels_path,
    index_root=None,
    collection_path=None,
    ncells_values=[1, 2, 4, 8, 16, 32],
    k=100,
    output_path=None,
    metric="success",
):
    """
    Perform grid search over retrieval parameters, measuring only retrieval latency.
    
    Args:
        checkpoint: ColBERT checkpoint path
        index_name: Name of the WARP index
        queries_path: Path to queries TSV file
        qrels_path: Path to qrels JSONL file with answer PIDs
        index_root: Root directory for indexes
        collection_path: Path to collection TSV file (optional, avoids hardcoded paths)
        ncells_values: List of ncells values to try
        k: Number of results to retrieve per query
        metric: Metric type - 'success' for LoTTE Success@k, 'mrr' for MS MARCO MRR@k
        output_path: Path to save results JSON
    """
    
    # Confirm single-threaded execution
    print("=" * 80)
    print("GRID SEARCH CONFIGURATION")
    print("=" * 80)
    print(f"PyTorch threads: {torch.get_num_threads()}")
    print(f"OMP_NUM_THREADS: {os.environ.get('OMP_NUM_THREADS', 'not set')}")
    print(f"MKL_NUM_THREADS: {os.environ.get('MKL_NUM_THREADS', 'not set')}")
    print(f"Metric type: {metric}")
    print(f"k value: {k}")
    print(f"ncells values: {ncells_values}")
    print("=" * 80)
    print()
    
    if index_root is None:
        index_root = os.environ.get("INDEX_ROOT")
        if index_root is None:
            raise ValueError("INDEX_ROOT not set")
    
    # If index_name is not provided, check if files are directly in index_root
    if index_name is None:
        if os.path.exists(os.path.join(index_root, "metadata.json")) or \
           os.path.exists(os.path.join(index_root, "plan.json")):
            # Files are directly in index_root, so we use the parent directory
            # as index_root and the directory name as index_name
            index_root, index_name = os.path.split(index_root.rstrip('/'))
            print(f"Index files found directly in specified path.")
            print(f"Using index_root: {index_root}")
            print(f"Using index_name: {index_name}")
            print()
        else:
            raise ValueError("--index-name not provided and index files not found directly in --index-root")
    
    # Load queries and qrels
    print(f"Loading queries from {queries_path}")
    queries = load_queries_tsv(queries_path)
    print(f"Loaded {len(queries)} queries")
    
    print(f"Loading qrels from {qrels_path}")
    if metric == "success":
        qrels = load_qrels_lotte(qrels_path)
    else:  # metric == "mrr" or other IR metrics
        qrels = load_qrels_msmarco(qrels_path)
    print(f"Loaded qrels for {len(qrels)} queries")
    
    results = []
    
    # Grid search over ncells
    for ncells in ncells_values:
        print(f"\n{'='*80}")
        print(f"Testing ncells={ncells}")
        print(f"{'='*80}")
        
        with Run().context(RunConfig(nranks=1, experiment="grid-search", amp=True)):
            config = ColBERTConfig(
                nbits=2,
                ncells=ncells,
                doc_maxlen=180,
                query_maxlen=32,
                dim=128,
                checkpoint=checkpoint,
                amp=True,
            )
            
            searcher = Searcher(
                index=index_name,
                checkpoint=checkpoint,
                config=config,
                index_root=index_root,
                collection=collection_path,
            )
            
            # Force ncells after Searcher initialization (index config may override it)
            searcher.config.ncells = ncells
            
            # Monkey-patch encode for AMP+GPU compatibility
            original_encode = searcher.encode
            def encode_with_half_conversion(text, full_length_search=False):
                Q = original_encode(text, full_length_search=full_length_search)
                if config.amp and config.total_visible_gpus > 0:
                    Q = Q.half().cuda()
                return Q
            searcher.encode = encode_with_half_conversion
            
            # STEP 1: Pre-encode all queries (measure encoding time separately)
            print(f"Encoding {len(queries)} queries...")
            queries_list = list(queries.values())
            encoding_start = time.time()
            Q = searcher.encode(queries_list, full_length_search=False)
            encoding_time = time.time() - encoding_start
            print(f"Encoding took {encoding_time:.3f}s ({encoding_time/len(queries)*1000:.2f}ms per query)")
            
            # STEP 2: Perform retrieval for each query (measure retrieval time only)
            print(f"Performing retrieval with ncells={ncells}...")
            query_ids = list(queries.keys())
            rankings = {}
            retrieval_times = []
            
            for i, (qid, Q_single) in enumerate(zip(query_ids, Q)):
                # Measure retrieval time for this query
                retrieval_start = time.time()
                pids, ranks, scores = searcher.dense_search(Q_single.unsqueeze(0), k=k)
                retrieval_time = time.time() - retrieval_start
                retrieval_times.append(retrieval_time)
                
                # Convert tensors to lists and store ranking
                pids_list = pids.cpu().tolist() if hasattr(pids, 'cpu') else pids
                scores_list = scores.cpu().tolist() if hasattr(scores, 'cpu') else scores
                rankings[qid] = [(pid, rank, score) for pid, rank, score in zip(pids_list, ranks, scores_list)]
                
                if (i + 1) % 100 == 0:
                    avg_latency = sum(retrieval_times) / len(retrieval_times) * 1000
                    print(f"  Processed {i+1}/{len(queries)} queries, avg retrieval latency: {avg_latency:.2f}ms")
            
            # Calculate metrics
            avg_retrieval_latency = sum(retrieval_times) / len(retrieval_times) * 1000  # ms
            p50_retrieval_latency = sorted(retrieval_times)[len(retrieval_times)//2] * 1000
            p95_retrieval_latency = sorted(retrieval_times)[int(len(retrieval_times)*0.95)] * 1000
            p99_retrieval_latency = sorted(retrieval_times)[int(len(retrieval_times)*0.99)] * 1000
            
            # Calculate metrics based on metric type
            eval_metrics = {}
            if metric == "success":
                # Calculate Success@k for different k values (LoTTE)
                for cutoff in [5, 10, 20, 50, 100]:
                    if cutoff <= k:
                        eval_metrics[f"Success@{cutoff}"] = calculate_success_at_k(qrels, rankings, cutoff)
            elif metric == "mrr":
                # Calculate IR metrics using pytrec_eval (MS MARCO)
                # This includes MRR@10, MAP@10, NDCG@10, Recall@10
                pytrec_metrics = calculate_metrics_with_pytrec(qrels, rankings, k_values=[k])
                eval_metrics.update(pytrec_metrics)
            
            result = {
                "ncells": ncells,
                "encoding_time_total_s": encoding_time,
                "encoding_latency_per_query_ms": encoding_time / len(queries) * 1000,
                "retrieval_latency_avg_ms": avg_retrieval_latency,
                "retrieval_latency_p50_ms": p50_retrieval_latency,
                "retrieval_latency_p95_ms": p95_retrieval_latency,
                "retrieval_latency_p99_ms": p99_retrieval_latency,
                **eval_metrics,
            }
            results.append(result)
            
            print(f"\nResults for ncells={ncells}:")
            print(f"  Encoding latency: {result['encoding_latency_per_query_ms']:.2f}ms/query")
            print(f"  Retrieval latency (avg): {result['retrieval_latency_avg_ms']:.2f}ms/query")
            print(f"  Retrieval latency (p95): {result['retrieval_latency_p95_ms']:.2f}ms/query")
            for metric_name, value in eval_metrics.items():
                if metric_name.startswith("MRR") or metric_name.startswith("map") or metric_name.startswith("ndcg") or metric_name.startswith("recall"):
                    print(f"  {metric_name}: {value:.4f}")
                else:
                    print(f"  {metric_name}: {value:.2f}%")
    
    # Print summary table
    print(f"\n{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    
    if metric == "success":
        print(f"{'ncells':<10} {'Enc(ms)':<10} {'Retr(ms)':<12} {'P95(ms)':<10} {'S@5':<8} {'S@10':<8} {'S@100':<8}")
        print("-" * 80)
        for r in results:
            print(f"{r['ncells']:<10} {r['encoding_latency_per_query_ms']:<10.2f} "
                  f"{r['retrieval_latency_avg_ms']:<12.2f} {r['retrieval_latency_p95_ms']:<10.2f} "
                  f"{r.get('Success@5', 0):<8.2f} {r.get('Success@10', 0):<8.2f} {r.get('Success@100', 0):<8.2f}")
    elif metric == "mrr":
        print(f"{'ncells':<10} {'Enc(ms)':<10} {'Retr(ms)':<12} {'P95(ms)':<10} {'MRR@10':<10} {'MAP@10':<10} {'NDCG@10':<10}")
        print("-" * 88)
        for r in results:
            print(f"{r['ncells']:<10} {r['encoding_latency_per_query_ms']:<10.2f} "
                  f"{r['retrieval_latency_avg_ms']:<12.2f} {r['retrieval_latency_p95_ms']:<10.2f} "
                  f"{r.get('MRR@10', 0):<10.4f} {r.get('map@10', 0):<10.4f} {r.get('ndcg@10', 0):<10.4f}")
    
    # Save results
    if output_path:
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {output_path}")
    
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Grid search for WARP retrieval parameters"
    )
    parser.add_argument("--checkpoint", type=str, required=True, help="ColBERT checkpoint")
    parser.add_argument("--index-name", type=str, default=None, 
                        help="Index name (optional if index files are directly in index-root)")
    parser.add_argument("--queries", type=str, required=True, help="Path to queries TSV")
    parser.add_argument("--qrels", type=str, required=True, help="Path to qrels JSONL file")
    parser.add_argument("--index-root", type=str, default=None, help="Index root directory")
    parser.add_argument("--collection", type=str, default=None, help="Path to collection TSV file (optional)")
    parser.add_argument("--ncells", type=str, default="1,2,4,8,16,32", help="Comma-separated ncells values")
    parser.add_argument("--k", type=str, default="10", help="k value for retrieval and MRR@k (default 10)")
    parser.add_argument("--metric", type=str, default="success", choices=["success", "mrr"], 
                        help="Metric to calculate: 'success' for LoTTE Success@k, 'mrr' for MS MARCO MRR@k")
    parser.add_argument("--output", type=str, default="/tmp/grid_search_results.json", help="Output JSON path")
    
    args = parser.parse_args()
    
    ncells_values = [int(x) for x in args.ncells.split(',')]
    k_value = int(args.k)
    
    grid_search_retrieval(
        checkpoint=args.checkpoint,
        index_name=args.index_name,
        queries_path=args.queries,
        qrels_path=args.qrels,
        index_root=args.index_root,
        collection_path=args.collection,
        ncells_values=ncells_values,
        k=k_value,
        output_path=args.output,
        metric=args.metric,
    )
