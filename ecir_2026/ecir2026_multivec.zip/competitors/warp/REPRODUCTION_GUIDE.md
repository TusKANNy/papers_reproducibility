# WARP Reproduction Guide

This guide provides step-by-step instructions to reproduce WARP experiments using pre-built indexes.

> **Note:** This guide is designed to be used with the official WARP repository. The scripts in this directory (`competitors/warp/`) should be copied to or run from the WARP repository after cloning. Update the paths in `run_grid_search.sh` to match your local data storage.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Downloading Pre-built Indexes](#downloading-pre-built-indexes)
- [Setup](#setup)
- [Running Grid Search](#running-grid-search)
- [Extracting Best Results](#extracting-best-results)

---

## Prerequisites

### Python Environment Setup

Create a conda environment with all required dependencies:

```bash
# Create conda environment from the provided file
conda env create -f conda_env_cpu.yml
conda activate warp
```

Alternatively, create the environment manually:

```bash
# Create conda environment
conda create -n warp python=3.8
conda activate warp

# Install conda packages
conda install -c pytorch pytorch-cpu=1.13
conda install -c conda-forge faiss-cpu gxx

# Install pip packages
pip install bitarray datasets gitpython ninja scipy tqdm transformers ujson \
    flask python-dotenv onnxruntime onnxruntime_tools coremltools beir \
    tabulate openvino matplotlib jsonlines optimum optimum-intel
```

---

## Downloading Pre-built Indexes

Pre-built indexes are available on Hugging Face:

### MS MARCO
- **Dataset**: [AnonymousUser2026/warp_ms_marco](https://huggingface.co/datasets/AnonymousUser2026/warp_ms_marco)

### LoTTE (Pooled)
- **Dataset**: [AnonymousUser2026/warp_lotte_pooled](https://huggingface.co/datasets/AnonymousUser2026/warp_lotte_pooled)

---

## Setup

### 1. Clone the Repository

```bash
git clone https://github.com/jlscheerer/xtr-warp.git
cd xtr-warp
```

### 2. Configure Paths

Edit `run_grid_search.sh` to set the base paths for your downloaded indexes:

```bash
# Update these two variables to match your setup:
LOTTE_BASE="/path/to/indexes/lotte"
MSMARCO_BASE="/path/to/indexes/ms_marco"
```

All other paths (index_files, queries, qrels, collection) are automatically derived from these base paths.

---

## Running Grid Search

The grid search evaluates WARP retrieval performance across different `ncells` values (number of centroid lists to probe). Lower `ncells` = faster but potentially lower accuracy; higher `ncells` = slower but higher accuracy.

### Running the Grid Search

```bash
# Make the script executable
chmod +x run_grid_search.sh

# Run grid search for both datasets
./run_grid_search.sh
```

**What the script does:**
1. Runs grid search on LoTTE with Success@5 metric
2. Runs grid search on MS MARCO with MRR@10 metric
3. Saves results to `results/lotte_grid_search_full.json` and `results/msmarco_grid_search_full.json`

---

## Extracting Best Results

After running the grid search, extract the best (fastest) configurations for specific metric thresholds:

### MS MARCO - Extract Best Configurations

```bash
python extract_best_warp_results.py \
    --input results/msmarco_grid_search_full.json \
    --output results/msmarco_best_results.tsv \
    --metric "MRR@10" \
    --cuts 0.39 0.392 0.394 0.396 0.398 0.399 0.4 0.402
```

### LoTTE - Extract Best Configurations

```bash
python extract_best_warp_results.py \
    --input results/lotte_grid_search_full.json \
    --output results/lotte_best_results.tsv \
    --metric "Success@5" \
    --cuts 0.67 0.675 0.68 0.685 0.69 0.695 0.70 0.705
```

**Output Format:** TSV files with the following columns:
- `cut`: Metric threshold
- `ncells`: Optimal ncells value for this threshold
- `[metric]`: Actual metric value achieved (MRR@10 or Success@5)
- `avg_latency_ms`: Average query latency in milliseconds
- `p50_latency_ms`, `p95_latency_ms`, `p99_latency_ms`: Latency percentiles
- `status`: `OK` if configuration found, `NOT_FOUND` otherwise