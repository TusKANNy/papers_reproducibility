#!/usr/bin/env python3
"""
Extract best results from IGP grid search experiments.

This script analyzes all performance results from a grid search and finds
the minimum latency configuration for each accuracy threshold.

Works for both MS MARCO (MRR@10) and LoTTE (Success@5) datasets.

Usage:
    python scripts/extract_best_results.py --config config/msmarco.json
    python scripts/extract_best_results.py --config config/lotte.json
"""

import argparse
import json
import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path
from typing import List, Dict

# Add parent directory to path
FILE_ABS_PATH = os.path.dirname(__file__)
ROOT_PATH = os.path.abspath(os.path.join(FILE_ABS_PATH, os.pardir))
sys.path.insert(0, ROOT_PATH)


def load_performance_files(config: dict) -> pd.DataFrame:
    """
    Load all performance JSON files from grid search results.
    
    Args:
        config: Dataset configuration dictionary
        
    Returns:
        DataFrame with columns: [nprobe, probe_topk, avg_time_ms, primary_metric, recall, ...]
    """
    data_root = config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
    results_dir = os.path.join(data_root, config['paths']['results_dir'])
    perf_dir = os.path.join(results_dir, config['output']['performance_subdir'])
    
    if not os.path.exists(perf_dir):
        print(f"ERROR: Performance directory not found: {perf_dir}")
        print("Make sure grid search has been run first.")
        sys.exit(1)
    
    print(f"Loading performance files from: {perf_dir}")
    
    json_files = list(Path(perf_dir).glob("*.json"))
    
    if not json_files:
        print(f"ERROR: No JSON files found in {perf_dir}")
        sys.exit(1)
    
    print(f"Found {len(json_files)} performance files\n")
    
    primary_metric = config['metrics']['primary']
    dataset_name = config['dataset']['name']
    
    records = []
    for json_file in json_files:
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            # Extract key metrics
            record = {
                'filename': json_file.name,
                'nprobe': data['retrieval']['nprobe'],
                'probe_topk': data['retrieval']['probe_topk'],
                'avg_time_ms': float(data['search_time']['retrieval_time_single_query_average(ms)']),
                'p50_time_ms': float(data['search_time']['retrieval_time_single_query_p50(ms)']),
                'p95_time_ms': float(data['search_time']['retrieval_time_single_query_p95(ms)']),
            }
            
            # Add accuracy metrics
            if 'recall_mean' in data['search_accuracy']:
                record['recall'] = float(data['search_accuracy']['recall_mean'])
            
            if 'mrr_mean' in data['search_accuracy']:
                record['mrr'] = float(data['search_accuracy']['mrr_mean'])
            
            if 'success_mean' in data['search_accuracy']:
                record['success'] = float(data['search_accuracy']['success_mean'])
            
            # Set primary metric
            if primary_metric == 'mrr':
                record['primary_metric'] = record.get('mrr', 0.0)
                record['metric_name'] = 'MRR'
            elif primary_metric == 'success':
                record['primary_metric'] = record.get('success', 0.0)
                record['metric_name'] = 'Success'
            else:
                print(f"WARNING: Unknown primary metric: {primary_metric}")
                record['primary_metric'] = 0.0
                record['metric_name'] = primary_metric
            
            records.append(record)
            
        except Exception as e:
            print(f"WARNING: Failed to parse {json_file.name}: {e}")
    
    if not records:
        print("ERROR: No valid performance data loaded")
        sys.exit(1)
    
    df = pd.DataFrame(records)
    
    # Sort by primary metric (descending) then by latency (ascending)
    df = df.sort_values(['primary_metric', 'avg_time_ms'], ascending=[False, True])
    
    print(f"✓ Loaded {len(df)} configurations")
    print(f"  Primary metric: {df['metric_name'].iloc[0]}")
    print(f"  Range: {df['primary_metric'].min():.4f} - {df['primary_metric'].max():.4f}")
    print()
    
    return df


def find_best_configs(df: pd.DataFrame, thresholds: List[float], 
                      metric_name: str, topk: int) -> pd.DataFrame:
    """
    Find minimum latency configuration for each accuracy threshold.
    
    Args:
        df: DataFrame with performance data
        thresholds: List of accuracy thresholds to analyze
        metric_name: Name of the primary metric (MRR, Success, etc.)
        topk: Top-k value used in experiments
        
    Returns:
        DataFrame with best configurations for each threshold
    """
    results = []
    
    print(f"Finding optimal configurations for {metric_name} thresholds...")
    print("-" * 80)
    
    for threshold in thresholds:
        # Filter configs that meet or exceed threshold
        valid_configs = df[df['primary_metric'] >= threshold]
        
        if len(valid_configs) == 0:
            print(f"{metric_name} >= {threshold:.4f}: No configuration achieves this threshold")
            continue
        
        # Find minimum latency among valid configs
        best_config = valid_configs.loc[valid_configs['avg_time_ms'].idxmin()]
        
        result = {
            f'{metric_name}_Threshold': threshold,
            'Min_Latency_ms': best_config['avg_time_ms'],
            'nprobe': best_config['nprobe'],
            'probe_topk': best_config['probe_topk'],
            f'Actual_{metric_name}': best_config['primary_metric'],
        }
        
        # Add other metrics if available
        if 'recall' in best_config:
            result['Recall'] = best_config['recall']
        if 'mrr' in best_config and metric_name != 'MRR':
            result[f'MRR@{topk}'] = best_config['mrr']
        if 'success' in best_config and metric_name != 'Success':
            result[f'Success@{topk}'] = best_config['success']
        
        results.append(result)
        
        # Print summary
        print(f"{metric_name} >= {threshold:.4f}:")
        print(f"  Optimal: nprobe={best_config['nprobe']}, probe_topk={best_config['probe_topk']}")
        print(f"  Latency: {best_config['avg_time_ms']:.2f} ms")
        print(f"  Actual {metric_name}: {best_config['primary_metric']:.4f}")
        if 'recall' in best_config:
            print(f"  Recall: {best_config['recall']:.4f}")
        print()
    
    if not results:
        print("ERROR: No valid configurations found for any threshold")
        return pd.DataFrame()
    
    return pd.DataFrame(results)


def generate_summary_stats(df: pd.DataFrame, config: dict):
    """Print summary statistics about the grid search results."""
    
    print("=" * 80)
    print("GRID SEARCH SUMMARY")
    print("=" * 80)
    
    dataset_name = config['dataset']['name'].upper()
    primary_metric = config['metrics']['primary']
    topk = config['retrieval']['topk']
    
    print(f"\nDataset: {dataset_name}")
    print(f"Primary Metric: {primary_metric.upper()}")
    print(f"Top-k: {topk}")
    print(f"Total Configurations: {len(df)}")
    print()
    
    # Latency statistics
    print("Latency (ms):")
    print(f"  Min:    {df['avg_time_ms'].min():.2f}")
    print(f"  Median: {df['avg_time_ms'].median():.2f}")
    print(f"  Max:    {df['avg_time_ms'].max():.2f}")
    print()
    
    # Accuracy statistics
    metric_col = 'primary_metric'
    metric_name = df['metric_name'].iloc[0]
    
    print(f"{metric_name}:")
    print(f"  Min:    {df[metric_col].min():.4f}")
    print(f"  Median: {df[metric_col].median():.4f}")
    print(f"  Max:    {df[metric_col].max():.4f}")
    print()
    
    if 'recall' in df.columns:
        print(f"Recall:")
        print(f"  Min:    {df['recall'].min():.4f}")
        print(f"  Median: {df['recall'].median():.4f}")
        print(f"  Max:    {df['recall'].max():.4f}")
        print()
    
    # Parameter ranges
    print("Parameter Ranges:")
    print(f"  nprobe:    {sorted(df['nprobe'].unique())}")
    print(f"  probe_topk: {sorted(df['probe_topk'].unique())}")
    print()
    
    # Best overall configuration
    best_idx = df['primary_metric'].idxmax()
    best = df.loc[best_idx]
    
    print("Best Configuration (highest accuracy):")
    print(f"  nprobe={best['nprobe']}, probe_topk={best['probe_topk']}")
    print(f"  {metric_name}: {best['primary_metric']:.4f}")
    print(f"  Latency: {best['avg_time_ms']:.2f} ms")
    if 'recall' in best:
        print(f"  Recall: {best['recall']:.4f}")
    print()
    
    # Fastest configuration
    fastest_idx = df['avg_time_ms'].idxmin()
    fastest = df.loc[fastest_idx]
    
    print("Fastest Configuration (lowest latency):")
    print(f"  nprobe={fastest['nprobe']}, probe_topk={fastest['probe_topk']}")
    print(f"  Latency: {fastest['avg_time_ms']:.2f} ms")
    print(f"  {metric_name}: {fastest['primary_metric']:.4f}")
    if 'recall' in fastest:
        print(f"  Recall: {fastest['recall']:.4f}")
    print()


def save_best_results(best_df: pd.DataFrame, config: dict):
    """Save best results to TSV file."""
    
    output_file = os.path.join(ROOT_PATH, config['output']['best_results_file'])
    
    # Format floats for better readability
    formatted_df = best_df.copy()
    for col in formatted_df.columns:
        if formatted_df[col].dtype == float:
            if 'Latency' in col:
                formatted_df[col] = formatted_df[col].round(2)
            else:
                formatted_df[col] = formatted_df[col].round(6)
    
    formatted_df.to_csv(output_file, sep='\t', index=False)
    
    print("=" * 80)
    print(f"✓ Best results saved to: {output_file}")
    print("=" * 80)
    print()
    
    # Display the results
    print("BEST CONFIGURATIONS TABLE")
    print("-" * 80)
    print(formatted_df.to_string(index=False))
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Extract best results from IGP grid search",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/extract_best_results.py --config config/msmarco.json
  python scripts/extract_best_results.py --config config/lotte.json

This script analyzes all performance JSON files from a grid search and
identifies the configuration with minimum latency for each accuracy threshold.
        """
    )
    parser.add_argument('--config', required=True,
                       help='Path to dataset configuration JSON file')
    
    args = parser.parse_args()
    
    # Load configuration
    if not os.path.exists(args.config):
        print(f"ERROR: Config file not found: {args.config}")
        sys.exit(1)
    
    with open(args.config, 'r') as f:
        config = json.load(f)
    
    print("=" * 80)
    print(f"IGP Results Extraction - {config['dataset']['name'].upper()}")
    print("=" * 80)
    print()
    
    # Load performance data
    df = load_performance_files(config)
    
    # Generate summary statistics
    generate_summary_stats(df, config)
    
    # Find best configurations for each threshold
    thresholds = config['metrics']['thresholds']
    primary_metric = config['metrics']['primary']
    topk = config['retrieval']['topk']
    
    if primary_metric == 'mrr':
        metric_name = 'MRR'
    elif primary_metric == 'success':
        metric_name = 'Success'
    else:
        metric_name = primary_metric.upper()
    
    best_df = find_best_configs(df, thresholds, metric_name, topk)
    
    if len(best_df) > 0:
        # Save results
        save_best_results(best_df, config)
    else:
        print("ERROR: No best configurations found")
        sys.exit(1)


if __name__ == "__main__":
    main()
