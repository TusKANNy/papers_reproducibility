#!/usr/bin/env python3
"""
Core IGP search module - loads index and executes retrieval.

This module provides the core search functionality used by grid_search.py.
It handles index loading, query processing, and retrieval with timing.
"""

import numpy as np
import os
import sys
import json
import importlib
from typing import Dict, Tuple

# Ensure single-threaded BLAS for consistent performance
os.environ["OPENBLAS_NUM_THREADS"] = "1"

# Add parent directory to path for imports
FILE_ABS_PATH = os.path.dirname(__file__)
ROOT_PATH = os.path.abspath(os.path.join(FILE_ABS_PATH, os.pardir))
sys.path.insert(0, ROOT_PATH)
sys.path.insert(0, os.path.join(ROOT_PATH, 'build'))


class IGPSearcher:
    """Wrapper for IGP index loading and search."""
    
    def __init__(self, config: dict):
        """
        Initialize IGP searcher with dataset configuration.
        
        Args:
            config: Dataset configuration dictionary (from JSON file)
        """
        self.config = config
        self.index = None
        self.IGP_module = None
        
    def load_index(self):
        """Load pre-built IGP index from disk."""
        print(f"Loading IGP index for {self.config['dataset']['name']}...")
        
        # Import IGP module
        try:
            self.IGP_module = importlib.import_module("IGP")
            print("✓ IGP module imported successfully")
        except ImportError as e:
            print(f"ERROR: Failed to import IGP module: {e}")
            print("Make sure the IGP module is built and in the Python path.")
            print(f"Current sys.path: {sys.path}")
            sys.exit(1)
        
        # Build index directory path
        data_root = self.config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
        index_dir = os.path.join(
            data_root,
            self.config['paths']['index_dir'],
            self.config['index']['index_name']
        )
        
        if not os.path.exists(index_dir):
            print(f"ERROR: Index directory not found: {index_dir}")
            sys.exit(1)
        
        print(f"Loading from: {index_dir}")
        
        # Load index components
        centroid_l = np.load(os.path.join(index_dir, 'centroid_l.npy'))
        vq_code_l = np.load(os.path.join(index_dir, 'vq_code_l.npy'))
        weight_l = np.load(os.path.join(index_dir, 'weight_l.npy'))
        residual_code_l = np.load(os.path.join(index_dir, 'residual_code_l.npy'))
        
        with open(os.path.join(index_dir, 'constructor_insert_item.json'), 'r') as f:
            constructor_insert_item = json.load(f)
        
        print(f"✓ Index files loaded:")
        print(f"  - n_centroid: {centroid_l.shape[0]}")
        print(f"  - total vectors: {len(vq_code_l):,}")
        print(f"  - residual size: {residual_code_l.nbytes / (1024**3):.2f} GB")
        
        # Create retriever instance
        self.index = self.IGP_module.DocRetrieval(**constructor_insert_item)
        
        # Load quantization index
        constructor_build_index = {
            'centroid_l': centroid_l,
            'vq_code_l': vq_code_l,
            'weight_l': weight_l,
            'residual_code_l': residual_code_l
        }
        self.index.load_quantization_index(**constructor_build_index)
        
        # Load graph index
        hnsw_path = os.path.join(index_dir, 'index.hnsw')
        self.index.load_graph_index(hnsw_path)
        
        print("✓ IGP index loaded successfully\n")
        
    def search(self, query_l: np.ndarray, nprobe: int, probe_topk: int, topk: int) -> Tuple:
        """
        Execute IGP search on queries.
        
        Args:
            query_l: Query embeddings (n_queries × n_vectors × dim)
            nprobe: Number of coarse clusters to probe
            probe_topk: Number of candidates per cluster
            topk: Number of top documents to retrieve
            
        Returns:
            Tuple of (distances, doc_ids, retrieval_times, filter_times, 
                     decode_times, refine_times, various statistics)
        """
        if self.index is None:
            raise RuntimeError("Index not loaded. Call load_index() first.")
        
        return self.index.search(
            query_l=query_l,
            topk=topk,
            nprobe=nprobe,
            probe_topk=probe_topk
        )


def load_queries(config: dict) -> Tuple[np.ndarray, list]:
    """
    Load query embeddings and query IDs.
    
    Args:
        config: Dataset configuration
        
    Returns:
        (query_embeddings, query_ids)
    """
    data_root = config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
    query_path = os.path.join(data_root, config['paths']['query_embedding'])
    
    if not os.path.exists(query_path):
        print(f"ERROR: Query embeddings not found: {query_path}")
        sys.exit(1)
    
    print(f"Loading queries from: {query_path}")
    query_l = np.load(query_path)
    
    # Verify shape
    expected_shape = tuple(config['dataset']['query_shape'])
    if query_l.shape != expected_shape:
        print(f"ERROR: Query shape mismatch!")
        print(f"  Expected: {expected_shape}")
        print(f"  Got: {query_l.shape}")
        sys.exit(1)
    
    print(f"✓ Loaded {len(query_l)} queries with shape {query_l.shape}")
    
    # Load query IDs from queries file
    data_root = config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
    queries_file = os.path.join(data_root, config['paths']['queries_file'])
    queryID_l = []
    
    if os.path.exists(queries_file):
        with open(queries_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split('\t')
                if len(parts) >= 1:
                    queryID_l.append(int(parts[0]))
        
        if len(queryID_l) != len(query_l):
            print(f"WARNING: Query ID count mismatch ({len(queryID_l)} vs {len(query_l)})")
            print("Using sequential IDs instead")
            queryID_l = list(range(len(query_l)))
    else:
        print(f"WARNING: Queries file not found: {queries_file}")
        print("Using sequential IDs")
        queryID_l = list(range(len(query_l)))
    
    print(f"✓ Query IDs loaded: {len(queryID_l)}\n")
    
    return query_l, queryID_l


def compute_search_metrics(retrieval_time_l: np.ndarray, 
                          filter_time_l: np.ndarray,
                          decode_time_l: np.ndarray, 
                          refine_time_l: np.ndarray,
                          n_sorted_ele_l: np.ndarray,
                          n_seen_item_l: np.ndarray,
                          n_refine_item_l: np.ndarray,
                          incremental_graph_n_compute_l: np.ndarray,
                          n_vq_score_refine_l: np.ndarray,
                          n_vq_score_linear_scan_l: np.ndarray) -> Dict:
    """
    Compute search performance statistics.
    
    Args:
        Various timing and statistics arrays from IGP search
        
    Returns:
        Dictionary with formatted metrics
    """
    return {
        "retrieval_time_single_query_p5(ms)": f"{np.percentile(retrieval_time_l, 5) * 1e3:.3f}",
        "retrieval_time_single_query_p50(ms)": f"{np.percentile(retrieval_time_l, 50) * 1e3:.3f}",
        "retrieval_time_single_query_p95(ms)": f"{np.percentile(retrieval_time_l, 95) * 1e3:.3f}",
        "retrieval_time_single_query_average(ms)": f"{np.average(retrieval_time_l) * 1e3:.3f}",
        
        "filter_time_average(ms)": f"{np.average(filter_time_l) * 1e3:.3f}",
        "decode_time_average(ms)": f"{np.average(decode_time_l) * 1e3:.3f}",
        "refine_time_average(ms)": f"{np.average(refine_time_l) * 1e3:.3f}",
        
        "n_sorted_ele_average": f"{np.average(n_sorted_ele_l):.3f}",
        "n_seen_item_average": f"{np.average(n_seen_item_l):.3f}",
        "n_refine_item_average": f"{np.average(n_refine_item_l):.3f}",
        "incremental_graph_n_compute_average": f"{np.average(incremental_graph_n_compute_l):.3f}",
        "n_vq_score_refine_average": f"{np.average(n_vq_score_refine_l):.3f}",
        "n_vq_score_linear_scan_average": f"{np.average(n_vq_score_linear_scan_l):.3f}",
    }


if __name__ == "__main__":
    # Simple test
    import argparse
    
    parser = argparse.ArgumentParser(description="Test IGP search module")
    parser.add_argument('--config', required=True, help='Path to dataset config JSON')
    args = parser.parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = json.load(f)
    
    print(f"=== Testing IGP Search for {config['dataset']['name']} ===\n")
    
    # Initialize searcher
    searcher = IGPSearcher(config)
    searcher.load_index()
    
    # Load queries
    query_l, queryID_l = load_queries(config)
    
    # Test single configuration
    nprobe = config['grid_search']['nprobe'][0]
    probe_topk = config['grid_search']['probe_topk'][0]
    topk = config['retrieval']['topk']
    
    print(f"Testing with nprobe={nprobe}, probe_topk={probe_topk}, topk={topk}...")
    
    results = searcher.search(query_l, nprobe, probe_topk, topk)
    est_dist_l, est_id_l = results[0], results[1]
    retrieval_time_l = results[2]
    
    print(f"\n✓ Search completed!")
    print(f"  - Retrieved {topk} docs for {len(query_l)} queries")
    print(f"  - Avg time: {np.mean(retrieval_time_l)*1000:.2f} ms")
    print(f"  - p50 time: {np.percentile(retrieval_time_l, 50)*1000:.2f} ms")
    print(f"  - p95 time: {np.percentile(retrieval_time_l, 95)*1000:.2f} ms")
