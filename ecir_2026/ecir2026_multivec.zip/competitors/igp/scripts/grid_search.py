#!/usr/bin/env python3
"""
Universal grid search script for IGP retrieval experiments.

This script runs grid search over IGP retrieval parameters for any dataset
(MS MARCO or LoTTE) using a configuration file.

Usage:
    python scripts/grid_search.py --config config/msmarco.json
    python scripts/grid_search.py --config config/lotte.json
"""

import argparse
import json
import numpy as np
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

# Add parent directory and scripts to path
FILE_ABS_PATH = os.path.dirname(__file__)
ROOT_PATH = os.path.abspath(os.path.join(FILE_ABS_PATH, os.pardir))
sys.path.insert(0, ROOT_PATH)
sys.path.insert(0, FILE_ABS_PATH)

# Import our search module
from search_igp import IGPSearcher, load_queries, compute_search_metrics


def load_groundtruth(config: dict) -> Tuple:
    """
    Load groundtruth data for accuracy evaluation.
    
    Returns:
        (mrr_gnd, recall_gnd_id_m) tuple
    """
    dataset_name = config['dataset']['name']
    topk = config['retrieval']['topk']
    
    print(f"Loading groundtruth data...")
    
    # Get data root
    data_root = config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
    
    # Load MRR groundtruth (queries.gnd.jsonl)
    mrr_gnd_file = os.path.join(data_root, config['paths']['groundtruth_mrr'])
    mrr_gnd_m = {}
    mrr_passageID_l = []
    
    if os.path.exists(mrr_gnd_file):
        with open(mrr_gnd_file, 'r', encoding='utf-8') as f:
            for line in f:
                query_gnd_json = json.loads(line)
                queryID = query_gnd_json['query_id']
                passageID_l = query_gnd_json['passage_id']
                mrr_gnd_m[queryID] = passageID_l
        
        # Load passage ID mapping from collection.tsv
        collection_file = os.path.join(data_root, config['paths']['collection'])
        with open(collection_file, 'r', encoding='utf-8') as f:
            for line in f:
                passageID = int(line.split('\t')[0])
                mrr_passageID_l.append(passageID)
        
        print(f"✓ Loaded MRR groundtruth: {len(mrr_gnd_m)} queries")
    else:
        print(f"WARNING: MRR groundtruth not found: {mrr_gnd_file}")
    
    # Load recall groundtruth (from embedding dir)
    recall_gnd_file = os.path.join(data_root, config['paths']['groundtruth_recall'])
    recall_gnd_id_m = {}
    
    if os.path.exists(recall_gnd_file):
        with open(recall_gnd_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split('\t')
                if len(parts) >= 3:
                    queryID = int(parts[0])
                    docID = int(parts[1])
                    rank = int(parts[2])
                    
                    if queryID not in recall_gnd_id_m:
                        recall_gnd_id_m[queryID] = []
                    recall_gnd_id_m[queryID].append([docID, rank])
        
        print(f"✓ Loaded recall groundtruth: {len(recall_gnd_id_m)} queries")
    else:
        print(f"WARNING: Recall groundtruth not found: {recall_gnd_file}")
    
    mrr_gnd = (len(mrr_gnd_m) > 0, mrr_gnd_m, mrr_passageID_l)
    
    return mrr_gnd, recall_gnd_id_m


def compute_mrr(est_id_m: dict, mrr_gnd_m: dict, mrr_passageID_l: list) -> List[float]:
    """Compute MRR scores."""
    mrr_l = []
    for queryID in est_id_m.keys():
        if queryID not in mrr_gnd_m:
            continue
        
        tmp_mrr = 0
        for local_passageID, rank in est_id_m[queryID]:
            if local_passageID >= len(mrr_passageID_l):
                continue
            global_passageID = mrr_passageID_l[local_passageID]
            if global_passageID in mrr_gnd_m[queryID]:
                tmp_mrr = 1.0 / rank
                break
        mrr_l.append(tmp_mrr)
    
    return mrr_l


def compute_success_at_k(est_id_m: dict, mrr_gnd_m: dict, mrr_passageID_l: list, topk: int) -> List[float]:
    """Compute Success@k scores - at least one relevant in top-k."""
    success_l = []
    for queryID in est_id_m.keys():
        if queryID not in mrr_gnd_m:
            continue
        
        relevant_doc_ids = set(mrr_gnd_m[queryID])
        found_relevant = False
        
        for local_passageID, rank in est_id_m[queryID]:
            if rank > topk:
                break
            if local_passageID >= len(mrr_passageID_l):
                continue
            
            global_passageID = mrr_passageID_l[local_passageID]
            if global_passageID in relevant_doc_ids:
                found_relevant = True
                break
        
        success_l.append(1.0 if found_relevant else 0.0)
    
    return success_l


def compute_recall(est_id_m: dict, recall_gnd_id_m: dict, topk: int) -> List[float]:
    """Compute recall scores."""
    recall_l = []
    for queryID in est_id_m.keys():
        if queryID not in recall_gnd_id_m:
            continue
        
        est_id_rank = np.array(est_id_m[queryID])
        est_id = est_id_rank[:, 0]
        gnd_id_rank = np.array(recall_gnd_id_m[queryID])
        gnd_id = gnd_id_rank[:, 0]
        
        recall = len(np.intersect1d(gnd_id, est_id)) / topk
        recall_l.append(recall)
    
    return recall_l


def save_results(config: dict, nprobe: int, probe_topk: int,
                 est_id_l: np.ndarray, queryID_l: List[int],
                 search_time_m: Dict, accuracy_m: Dict,
                 retrieval_time_ms_l: np.ndarray):
    """Save performance metrics, answer file, and per-query stats."""
    
    dataset_name = config['dataset']['name']
    topk = config['retrieval']['topk']
    index_name = config['index']['index_name']
    method_name = config['index']['method']
    
    data_root = config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
    results_dir = os.path.join(data_root, config['paths']['results_dir'])
    
    # Create output subdirectories
    perf_dir = os.path.join(results_dir, config['output']['performance_subdir'])
    answer_dir = os.path.join(results_dir, config['output']['answer_subdir'])
    single_query_dir = os.path.join(results_dir, config['output']['single_query_subdir'])
    
    for d in [perf_dir, answer_dir, single_query_dir]:
        os.makedirs(d, exist_ok=True)
    
    # Base filename
    base_name = f"{dataset_name}-retrieval-{method_name}-top{topk}-{index_name}-nprobe_{nprobe}-probe_topk_{probe_topk}"
    
    # 1. Save performance JSON
    performance_data = {
        "dataset": dataset_name,
        "method": method_name,
        "index": index_name,
        "retrieval": {
            "nprobe": nprobe,
            "probe_topk": probe_topk,
            "topk": topk
        },
        "search_time": search_time_m,
        "search_accuracy": accuracy_m
    }
    
    perf_file = os.path.join(perf_dir, f"{base_name}.json")
    with open(perf_file, 'w') as f:
        json.dump(performance_data, f, indent=2)
    
    # 2. Save answer TSV
    answer_file = os.path.join(answer_dir, f"{base_name}.tsv")
    with open(answer_file, 'w', encoding='utf-8') as f:
        for i, queryID in enumerate(queryID_l):
            doc_ids = ','.join(str(int(doc_id)) for doc_id in est_id_l[i])
            f.write(f"{queryID}\t{doc_ids}\n")
    
    # 3. Save per-query performance CSV
    single_query_file = os.path.join(single_query_dir, f"{base_name}.csv")
    with open(single_query_file, 'w') as f:
        f.write("queryID,retrieval_time_ms\n")
        for i, queryID in enumerate(queryID_l):
            f.write(f"{queryID},{retrieval_time_ms_l[i]:.3f}\n")
    
    print(f"  ✓ Results saved: {base_name}")


def run_grid_search(config: dict):
    """Execute grid search for all parameter combinations."""
    
    print("="*80)
    print(f"IGP Grid Search - {config['dataset']['name'].upper()}")
    print("="*80)
    print()
    
    # Initialize searcher and load index
    print("Step 1: Loading IGP index...")
    searcher = IGPSearcher(config)
    searcher.load_index()
    
    # Load queries
    print("Step 2: Loading queries...")
    query_l, queryID_l = load_queries(config)
    
    # Load groundtruth
    print("Step 3: Loading groundtruth...")
    mrr_gnd, recall_gnd_id_m = load_groundtruth(config)
    has_mrr, mrr_gnd_m, mrr_passageID_l = mrr_gnd
    
    # Generate parameter grid
    nprobe_list = config['grid_search']['nprobe']
    probe_topk_list = config['grid_search']['probe_topk']
    topk = config['retrieval']['topk']
    
    param_configs = []
    for nprobe in nprobe_list:
        for probe_topk in probe_topk_list:
            param_configs.append({'nprobe': nprobe, 'probe_topk': probe_topk})
    
    print(f"\nStep 4: Running grid search...")
    print(f"  - nprobe values: {nprobe_list}")
    print(f"  - probe_topk values: {probe_topk_list}")
    print(f"  - Total configurations: {len(param_configs)}")
    print(f"  - Queries: {len(query_l)}")
    print(f"  - Top-k: {topk}")
    print()
    
    # Run each configuration
    primary_metric = config['metrics']['primary']
    
    for idx, params in enumerate(param_configs, 1):
        nprobe = params['nprobe']
        probe_topk = params['probe_topk']
        
        print(f"[{idx}/{len(param_configs)}] nprobe={nprobe}, probe_topk={probe_topk}")
        start_time = time.time()
        
        # Execute search
        results = searcher.search(query_l, nprobe, probe_topk, topk)
        est_dist_l = results[0]
        est_id_l = results[1]
        retrieval_time_l = results[2]
        
        # Compute timing metrics
        search_time_m = compute_search_metrics(*results[2:])
        
        # Convert to per-query dict format for accuracy computation
        est_id_m = {}
        for i, queryID in enumerate(queryID_l):
            est_id_m[queryID] = [[int(doc_id), rank+1] for rank, doc_id in enumerate(est_id_l[i])]
        
        # Compute accuracy metrics
        accuracy_m = {}
        
        # Get success_at_k if specified (for metrics like Success@5 from top-10)
        success_at_k = config['metrics'].get('success_at_k', topk)
        
        # Recall
        if len(recall_gnd_id_m) > 0:
            recall_l = compute_recall(est_id_m, recall_gnd_id_m, topk)
            accuracy_m['recall_mean'] = f"{np.mean(recall_l):.6f}"
        
        # MRR
        if has_mrr:
            mrr_l = compute_mrr(est_id_m, mrr_gnd_m, mrr_passageID_l)
            accuracy_m['mrr_mean'] = f"{np.mean(mrr_l):.6f}"
        
        # Success@k (for LoTTE) - can be different from topk
        if has_mrr and primary_metric == 'success':
            success_l = compute_success_at_k(est_id_m, mrr_gnd_m, mrr_passageID_l, success_at_k)
            accuracy_m['success_mean'] = f"{np.mean(success_l):.6f}"
            accuracy_m['success_at_k'] = success_at_k  # Store which k was used
        
        # Save results
        retrieval_time_ms_l = retrieval_time_l * 1000
        save_results(config, nprobe, probe_topk, est_id_l, queryID_l,
                    search_time_m, accuracy_m, retrieval_time_ms_l)
        
        elapsed = time.time() - start_time
        avg_time = float(search_time_m['retrieval_time_single_query_average(ms)'])
        
        print(f"  Time: {elapsed:.1f}s | Avg query: {avg_time:.2f}ms | ", end='')
        
        if primary_metric == 'mrr' and 'mrr_mean' in accuracy_m:
            print(f"MRR: {accuracy_m['mrr_mean']} | ", end='')
        elif primary_metric == 'success' and 'success_mean' in accuracy_m:
            success_k = accuracy_m.get('success_at_k', topk)
            print(f"Success@{success_k}: {accuracy_m['success_mean']} | ", end='')
        
        if 'recall_mean' in accuracy_m:
            print(f"Recall: {accuracy_m['recall_mean']}")
        else:
            print()
    
    print()
    print("="*80)
    print("Grid search completed!")
    data_root = config['paths'].get('data_root', os.path.join(ROOT_PATH, 'Dataset/multi-vector-retrieval'))
    print(f"Results saved to: {os.path.join(data_root, config['paths']['results_dir'])}")
    print()
    print("Next step: Run extract_best_results.py to analyze results")
    print("="*80)


def main():
    parser = argparse.ArgumentParser(
        description="Run IGP grid search experiment",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/grid_search.py --config config/msmarco.json
  python scripts/grid_search.py --config config/lotte.json
        """
    )
    parser.add_argument('--config', required=True, 
                       help='Path to dataset configuration JSON file')
    
    args = parser.parse_args()
    
    # Load configuration
    if not os.path.exists(args.config):
        print(f"ERROR: Config file not found: {args.config}")
        sys.exit(1)
    
    with open(args.config, 'r') as f:
        config = json.load(f)
    
    # Run grid search
    run_grid_search(config)


if __name__ == "__main__":
    main()
