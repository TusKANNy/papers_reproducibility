# IGP Reproducibility Guide

Reproduce IGP experiments on MS MARCO and LoTTE datasets using pre-built indexes.

> **Note:** This guide is designed to be used with the official IGP repository. The scripts in this directory (`competitors/igp/scripts/`) should be copied to the IGP repository after cloning. The configuration files (`competitors/igp/config/`) reference paths that need to be updated to match your local data storage.


### Install Dependencies

```bash
# System libraries
sudo apt install -y libeigen3-dev libopenblas-dev libspdlog-dev build-essential cmake git

# Python environment
conda create -n igp_repro python=3.8 -y
conda activate igp_repro
pip install numpy pandas tqdm torch faiss-cpu
```

## Setup

### 1. Clone Repository
```bash
git clone https://github.com/DBGroup-SUSTech/multi-vector-retrieval.git
cd multi-vector-retrieval
```

### 2. Build IGP Module
```bash
sed -i 's/set(USE_CUDA ON)/set(USE_CUDA OFF)/' CMakeLists.txt
mkdir -p build && cd build
cmake .. && make -j$(nproc)
cd ..
```

**Note**: Alternatively, manually edit `CMakeLists.txt` line 140 to set `USE_CUDA OFF`.

### 3. Fix libstdc++ (if needed)
```bash
rm $CONDA_PREFIX/lib/libstdc++.so.6
ln -s /usr/lib/x86_64-linux-gnu/libstdc++.so.6 $CONDA_PREFIX/lib/libstdc++.so.6
```

### 4. Download Data
Download from [SharePoint](https://connectpolyu-my.sharepoint.com/:f:/g/personal/21041743r_connect_polyu_hk/ElyiRI2Y0FNPmoP0ecApAUwB3v3gL_aNSHZaIrifCV_jDA) and extract to your preferred location. Structure:
```
/your/data/path/
├── Embedding/
├── Index/
└── RawData/
```

### 5. Configure Data Path
Edit `config/msmarco.json` and `config/lotte.json`, set `data_root`:
```json
"paths": {
  "data_root": "/your/data/path",
  ...
}
```

## Run Experiments

### MS MARCO
```bash
python scripts/grid_search.py --config config/msmarco.json
python scripts/extract_best_results.py --config config/msmarco.json
cat best_results_msmarco.tsv
```

### LoTTE  
```bash
python scripts/grid_search.py --config config/lotte.json
python scripts/extract_best_results.py --config config/lotte.json
cat best_results_lotte.tsv
```

## Configuration

**MS MARCO** (`config/msmarco.json`):
- Metric: MRR@10

**LoTTE** (`config/lotte.json`):
- Metric: Success@5 (computed from top-10 retrieval)

## Output

Each experiment generates:
- `<data_root>/Result/performance_<dataset>/*.json` - Metrics per config
- `<data_root>/Result/answer_<dataset>/*.tsv` - Retrieved doc IDs  
- `best_results_<dataset>.tsv` - Optimal configs per accuracy threshold (saved in repository root)

**Note**: `<data_root>` is the path you configured in the JSON files. The final `best_results_*.tsv` file is saved in your repository directory.

## Troubleshooting

**GLIBCXX error**: Run step 3 above

**Module not found**: 
```bash
export PYTHONPATH="${PWD}:${PWD}/build:${PYTHONPATH}"
```

- `config/msmarco.json` - MS MARCO parameters
- `config/lotte.json` - LoTTE parameters  
- `scripts/grid_search.py` - Run experiments
- `scripts/extract_best_results.py` - Analyze results
- `Dataset/multi-vector-retrieval/` - Data directory
- `best_results_<dataset>.tsv` - Final output

