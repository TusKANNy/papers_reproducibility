#!/usr/bin/env python3
"""Extract best (fastest) grid-search configurations per metric cut.

Reads a single TSV file with header columns including:
k\tnprobe\tthresh\tthresh_query\tn_doc_to_score\tout_second_stage\tavg_query_time_ns\tmrr@10\trecall@10

For each metric cut (user-specified or generated from unique metric values), the script selects
the row with the minimal `avg_query_time_ns` among rows whose metric value >= cut.

Writes results as TSV to stdout or to a file.
"""

from __future__ import annotations

import argparse
import csv
import sys
from typing import Dict, List, Tuple


def parse_args():
    p = argparse.ArgumentParser(description="Extract fastest configuration per metric cut from a single TSV file")
    p.add_argument("input", nargs="?", default="grid_results_m32.tsv", help="Input TSV file path")
    p.add_argument("--cuts", nargs="*", type=float, help="Metric cut values (e.g. 0.38 0.39). If omitted, uses unique metric values from file sorted ascending")
    p.add_argument("--output", "-o", help="Output TSV file path (default stdout)")
    p.add_argument("--metric-col", default="mrr@10", help="Name of the metric column in header")
    return p.parse_args()


def read_tsv(filepath: str) -> Tuple[List[str], List[Dict[str, str]]]:
    with open(filepath, "r", newline="") as fh:
        reader = csv.DictReader(fh, delimiter="\t")
        header = reader.fieldnames or []
        rows = [row for row in reader]
    return header, rows


def to_float_safe(s: str) -> float:
    try:
        return float(s)
    except Exception:
        return float("nan")


def select_best_for_cut(rows: List[Dict[str, str]], metric_col: str, cut: float) -> Dict[str, str] | None:
    # Filter rows with metric >= cut
    filtered = [r for r in rows if to_float_safe(r.get(metric_col, "nan")) >= cut]
    if not filtered:
        return None
    # Select row with minimal avg time
    best = min(filtered, key=lambda r: to_float_safe(r.get("avg_query_time_ns", "nan")))
    return best


def main():
    args = parse_args()
    header, rows = read_tsv(args.input)

    if args.metric_col not in header:
        print(f"Error: metric column '{args.metric_col}' not found in input header", file=sys.stderr)
        sys.exit(2)

    # Determine cuts. Default: range 0.39 -> 0.404 step 0.001 inclusive
    if args.cuts:
        cuts = sorted(set(args.cuts))
    else:
        start = 0.39
        end = 0.404
        step = 0.001
        steps = int(round((end - start) / step)) + 1
        cuts = [round(start + i * step, 6) for i in range(0, steps)]

    results: List[Dict[str, str]] = []
    for cut in cuts:
        best = select_best_for_cut(rows, args.metric_col, cut)
        if best is None:
            # write placeholder row with '/' for unavailable values
            empty_row = {k: '/' for k in header}
            empty_row['metric_cut'] = f"{cut:.6f}"
            # ensure time column shows '/'
            empty_row["avg_query_time_ns"] = '/'
            results.append(empty_row)
            continue
        out = dict(best)
        out["metric_cut"] = f"{cut:.6f}"
        results.append(out)

    # Output header: metric_cut + original header
    out_header = ["metric_cut"] + header

    if args.output:
        out_f = open(args.output, "w", newline="")
    else:
        out_f = sys.stdout

    writer = csv.DictWriter(out_f, fieldnames=out_header, delimiter="\t")
    writer.writeheader()
    for r in results:
        # Ensure all header fields exist
        row = {k: r.get(k, "") for k in out_header}
        writer.writerow(row)

    if args.output:
        out_f.close()


if __name__ == "__main__":
    main()
