# Multi-Vector Reranking Experiments

## Table of Contents

- [Reproducing Our Experiments](#reproducing-our-experiments)
  - [Downloading the Datasets](#downloading-the-datasets)
  - [Prerequisites](#prerequisites)
  - [Quick Reproduction Steps](#quick-reproduction-steps)
  - [Grid Search](#grid-search)
  - [Understanding the Binaries](#understanding-the-binaries)
- [Reproducing Competitor Baselines](#reproducing-competitor-baselines)
  - [EMVB](#emvb)
  - [IGP](#igp)
  - [WARP](#warp)

---

## Reproducing Our Experiments

This repository contains the code and scripts to reproduce the experimental results from our paper.

There are two main experimental workflows:

1. **kANNolo experiments**: End-to-end retrieval using kANNolo's graph index for first stage.
2. **SEISMIC experiments**: Two-stage pipeline using SEISMIC's first-stage retrieval followed by our reranking.

Both workflows are driven by the Python script `scripts/run_experiments.py` and configured via TOML files under `experiments/multivec_rerank/`.

### Downloading the datasets

All datasets used in the paper are available on Hugging Face: [https://huggingface.co/AnonymousUser2026](https://huggingface.co/AnonymousUser2026)

The datasets are organized in two collections:

#### MS MARCO Collection
📦 [https://huggingface.co/collections/AnonymousUser2026/ms-marco](https://huggingface.co/collections/AnonymousUser2026/ms-marco)

**Available datasets:**
- [ms_marco_cocondenser](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_cocondenser) - SPLADE CoCondenser sparse vectors (for first-stage retrieval)
- [ms_marco_inferenceless](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_inferenceless) - Inferenceless sparse vectors (for SEISMIC first-stage retrieval)
- [ms_marco_half_precision](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_half_precision) - Half-precision (f16) multivectors
- [ms_marco_jmpq32](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_jmpq32) - Compressed multivectors (JMPQ, m=32)
- [ms_marco_jmpq16](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_jmpq16) - Compressed multivectors (JMPQ, m=16)
- [ms_marco_mopq32](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_mopq32) - Compressed multivectors (MOPQ, m=32)

**Evaluation metric:** MRR@10

#### LoTTE (Pooled) Collection
📦 [https://huggingface.co/collections/AnonymousUser2026/lotte-pooled](https://huggingface.co/collections/AnonymousUser2026/lotte-pooled)

**Available datasets:**
- [lotte_pooled_cocondenser](https://huggingface.co/datasets/AnonymousUser2026/lotte_pooled_cocondenser) - SPLADE CoCondenser sparse vectors (for first-stage retrieval)
- [lotte_pooled_inferenceless](https://huggingface.co/datasets/AnonymousUser2026/lotte_pooled_inferenceless) - Inferenceless sparse vectors (for SEISMIC first-stage retrieval)
- [lotte_pooled_half_precision](https://huggingface.co/datasets/AnonymousUser2026/lotte_pooled_half_precision) - Half-precision (f16) multivectors
- [lotte_pooled_mopq32](https://huggingface.co/datasets/AnonymousUser2026/lotte_pooled_mopq32) - Compressed multivectors (MOPQ, m=32)

**Evaluation metric:** Success@5

#### What each dataset contains

**CoCondenser datasets** (for first-stage retrieval):
- `documents.bin` - Sparse document vectors (use this to build SEISMIC indexes)
- `queries.bin` - Sparse query vectors
- `groundtruth.tsv` / `groundtruth_50.tsv` - Pre-computed groundtruth for accuracy evaluation (used by SEISMIC to create candidate sets at given accuracy cut-offs)
- `doc_ids.npy` / `queries_ids.npy` - Document and query identifiers
- **Relevance judgments (qrels):**
  - MS MARCO: [`qrels.dev.small.tsv`](https://huggingface.co/datasets/AnonymousUser2026/ms_marco_cocondenser/blob/main/qrels.dev.small.tsv) - for computing MRR@10
  - LoTTE: [`lotte_pooled_qas.search.tsv`](https://huggingface.co/datasets/AnonymousUser2026/lotte_pooled_cocondenser/blob/main/lotte_pooled_qas.search.tsv) - for computing Success@5
- **kANNolo index** - Pre-built graph index (ready to use, no need to build)

**Inferenceless datasets** (for SEISMIC first-stage retrieval):
- Same structure as CoCondenser datasets above, but **without the kANNolo graph index**
- These datasets have been employed for SEISMIC-only experiments
- Use them the same way as CoCondenser datasets for SEISMIC first-stage retrieval

**Half-precision multivector datasets** (for reranking):
- `documents.npy` - 2D array (u16 values to be interpreted as f16) containing document vectors
- `queries.npy` - Multivector queries (f32, 3D array)
- `doclens.npy` - Number of vectors per document

**Compressed multivector datasets** (for reranking):
- `doclens.npy` - Number of vectors per document
- `queries.npy` - Multivector queries
- Compression-specific files:
  - **JMPQ/MOPQ:** `centroids.npy`, `index_assignment.npy`, `pq_centroids.npy`, `residuals.npy`


---

### Prerequisites

Before reproducing the experiments you need:

**Rust toolchain** (required to compile the binaries):

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

**Python dependencies** (for the experiment runner):

```bash
pip install -r scripts/requirements.txt
```

This installs: `ir_measures`, `numpy`, `pandas`, `psutil`, `termcolor`, and `toml`.

---

### Quick reproduction steps

1. **Compile the binaries:**

```bash
RUSTFLAGS="-C target-cpu=native" cargo build --release
```

2. **Run experiments:**

The experimental workflow differs between kANNolo and SEISMIC:

#### kANNolo experiments (end-to-end)

For kANNolo, you run experiments directly using the TOML configuration files. The runner will execute the entire pipeline: build the graph index (if needed), run queries, and evaluate results.

```bash
python3 scripts/run_experiments.py --exp experiments/multivec_rerank/rerank_plain_msmarco.toml
```

The TOML files configure:
- Graph construction parameters (M, ef_construction, etc.)
- Query parameters (k_candidates, alpha, beta)
- Multi-vector encoding type (plain, pq, two_levels)
- Dataset paths and evaluation settings

#### SEISMIC experiments (three-step workflow)

To run reranking experiments with SEISMIC first-stage retrieval, you need to:
1. Run SEISMIC grid search to find optimal first-stage configurations
2. Extract best SEISMIC results at different recall cutoffs
3. Configure and run reranking experiments using the extracted candidates

##### Step 1: Run SEISMIC grid search

Clone and set up SEISMIC in a separate directory:
```bash
git clone https://github.com/TusKANNy/seismic.git
cd seismic
```

**Use our provided SEISMIC configuration files** for the four experimental scenarios. These files are located in `seismic_aux_files/` of this repository:
- `grid_search_msmarco_v1_cocond.toml` - MS MARCO with CoCondenser vectors
- `grid_search_msmarco_v1_inferenceless.toml` - MS MARCO with Inferenceless vectors  
- `grid_search_lotte_cocond.toml` - LoTTE with CoCondenser vectors
- `grid_search_lotte_inferenceless_big.toml` - LoTTE with Inferenceless vectors

Copy the appropriate config file to the SEISMIC repository and update the paths in the `[folder]` section, then run:
```bash
# Example for MS MARCO CoCondenser
python scripts/run_grid_search.py --exp grid_search_msmarco_v1_cocond.toml
```

This will produce a grid search output directory containing multiple `building_combination_*` folders, each with:
- `report.tsv` - Performance metrics (Accuracy/Recall, RR@10, query time) for different query configurations
- `results_combination_*` - Candidate TSV files with top-k retrieval results

##### Step 2: Extract best SEISMIC results

Use our `seismic_aux_files/seismic_extract_best_results.py` script to find the fastest SEISMIC configuration for each accuracy cutoff:

```bash
python3 seismic_aux_files/seismic_extract_best_results.py \
    <grid_search_output_dir> \
    <best_results_output_dir> \
    --recall-cuts 0.90 0.91 0.92 0.93 0.94 0.95 0.96 0.97 0.98 0.99
```

This script:
- Analyzes all SEISMIC grid search results
- For each recall cutoff, finds the configuration with minimum query time that achieves accuracy ≥ cutoff
- Creates `best_results_output_dir/` containing:
  - `report_best.tsv` - Summary with recall_cut, time (microseconds), and mrr for each cutoff
  - `results_recall_<cut>_combination_<N>` - Candidate TSV files for each recall cutoff

##### Step 3: Run reranking experiments

Configure your SEISMIC reranking TOML file (e.g., `seismic_rerank_two_levels_msmarco.toml`):

1. Set `candidates_tsv` to the candidate file from Step 2 for your chosen recall cutoff:
   ```toml
   [filename]
   candidates_tsv = "/path/to/best_results_msmarco_cocondenser/results_recall_0.96_combination_9"
   ```

2. Set `first_stage_time_us` from the corresponding time in `report_best.tsv`:
   ```toml
   [reranking]
   first_stage_time_us = 587  # From report_best.tsv for recall_cut=0.96
   ```

3. Run the reranking experiment:
   ```bash
   python3 scripts/run_experiments.py --exp experiments/multivec_rerank/seismic_rerank_two_levels_msmarco.toml
   ```

The reranking step reads the first-stage candidates and applies multi-vector reranking to improve precision, tracking total query time (first-stage + reranking).

---

### Grid search

To reproduce the grid search over reranking hyperparameters (κ, α, β) as described in the paper, use the provided shell script:

```bash
./scripts/run_grid_search.sh -c experiments/multivec_rerank/rerank_plain_msmarco.toml
```

This script systematically tests all combinations of:
- **κ (k_candidates)**: 15, 20, 25, 30, 35, 40, 50
- **α (alpha)**: 0.015, 0.025, 0.050, off (pruning disabled)
- **β (beta)**: 2, 3, 4, off (early exit disabled)

The script:
1. Creates a temporary copy of your base TOML config for each parameter combination
2. Runs the experiment using `run_experiments.py`
3. Organizes results in timestamped folders under `grid_search_results/`
4. Generates `grid_search_results/grid_search_summary.tsv` with all configurations

**Extract best results:**

After the grid search completes, extract the fastest configurations per metric cut:

```bash
# Auto-generate cuts based on data range
python scripts/extract_best_results.py

# Specify custom metric cuts
python scripts/extract_best_results.py --cuts 0.390 0.392 0.394 0.396 0.398 0.399 0.4

# Save to file
python scripts/extract_best_results.py --cuts 0.390 0.392 0.394 0.396 0.398 0.399 0.4 -o grid_search_results/best_results.tsv
```

---

### Understanding the binaries

The repository includes two main binaries for multi-vector search:

1. **`hnsw_rerank_search`**: Used for kANNolo experiments (end-to-end search with graph-based first stage and multi-vector reranking)
2. **`rerank_from_file`**: Used for SEISMIC experiments (reranks candidates from a TSV file)

#### File format requirements

The Rust rerank binaries (invoked by the runner) expect the multivector data directory to contain different file sets depending on `--multivec-type`. See `src/bin/hnsw_rerank_search.rs` and `src/bin/rerank_from_file.rs` for the exact behavior. Summary:

- **Plain multivector format** (multivec_type = `plain`)
  - `documents.npy` : flattened 2D array (u16 values reinterpreted as f16 in code) containing all document vectors concatenated
  - `doclens.npy`   : 1D array with the number of vectors (num sub-vectors) for each document; used to slice `documents.npy`
  - `queries.npy`   : 3D float32 array of shape (num_queries, num_vectors_per_query, vector_dim) or flattened equivalent; the code reads this as a flattened 3D array

- **PQ / Product Quantizer format** (multivec_type = `pq`)
  - `centroids.npy`         : PQ centroids (expected as an Array3<f32> of shape [m, k, subvector_dim], but the code is tolerant and can accept 2D/1D variants when applicable)
  - `documents_codes.npy`   : 2D u8 array of PQ codes; each document's vectors are represented by `m` codes per vector
  - `doclens.npy`           : as above, lengths per document
  - `queries.npy`           : multivector queries (f32) — always expected at `<multivec_data_dir>/queries.npy`

- **Two-level format** (multivec_type = `two_levels`)
  - `centroids.npy`         : first-level centroids (2D f32 array: num_centroids x centroid_dim)
  - `index_assignment.npy`  : mapping of documents to first-level centroids
  - `pq_centroids.npy`      : centroids used by the residual PQ (can be 3D/2D/1D — code attempts multiple reads)
  - `residuals.npy`         : PQ codes (u8) for residuals; treated similarly to `documents_codes.npy` but for the residual quantizer
  - `doclens.npy`           : as above
  - `queries.npy`           : multivector queries (f32)

**Important notes:**
- The binary validates that the `vector_dim` passed via CLI (or TOML) matches the loaded data; if the dimensions do not match it will return an error.
- **Strict ordering requirement:** Documents and queries MUST HAVE THE SAME ORDER in the sparse (first-stage) data and in the multivec (second-stage) data. If using your own data, be sure to match the orders of first and second stage documents and queries.

---
---

## Reproducing Competitor Baselines

This repository includes scripts for reproducing experiments with competitor multi-vector retrieval systems. The scripts are located in the `competitors/` directory and should be used within the respective official repositories of each competitor.

---

### EMVB

**Official repository:** [https://github.com/CosimoRulli/emvb](https://github.com/CosimoRulli/emvb)

**Pre-built indexes:** [http://hpc.isti.cnr.it/~rulli/emvb-ecir2024/](http://hpc.isti.cnr.it/~rulli/emvb-ecir2024/)

#### Setup

1. **Clone and set up the EMVB repository:**
   ```bash
   git clone https://github.com/CosimoRulli/emvb.git
   cd emvb
   # Follow the setup instructions in the EMVB README
   ```

2. **Download pre-built indexes** from the link above.

#### Running experiments

This repository provides three helper scripts in `competitors/emvb/` that should be copied to and used within the EMVB repository:

**Grid search scripts:**
- `competitors/emvb/grid_search_ms_marco.sh` - Performs grid search on MS MARCO dataset
- `competitors/emvb/grid_search_lotte.sh` - Performs grid search on LoTTE dataset

**Usage:**
```bash
# Copy scripts to the EMVB repository directory
cp competitors/emvb/*.sh .
cp competitors/emvb/*.py .

# Run grid search for MS MARCO
./grid_search_ms_marco.sh output_results.tsv /path/to/index

# Run grid search for LoTTE
./grid_search_lotte.sh output_results.tsv /path/to/index
```

**Important note for MS MARCO grid search:** The `grid_search_ms_marco.sh` script contains two possible `THRESH_QUERY` parameter ranges (lines 23-24). Choose the appropriate one based on your index:
- Use `THRESH_QUERY=(0.3 0.4 0.5)` for indexes with `m=16`
- Use `THRESH_QUERY=(0.4 0.5 0.6)` for indexes with `m=32`

Uncomment the appropriate line in the script before running.

**Extracting best results:**

After running the grid search, use the extraction script to identify the best (fastest) configurations per metric cut:

```bash
# For MS MARCO (uses mrr@10 metric)
python extract_perf_grid_search.py output_results.tsv --output best_results.tsv --metric-col "mrr@10" --cuts 0.390 0.392 0.394 0.396 0.398 0.399 0.4 0.402

# For LoTTE (uses success@5 metric)
python extract_perf_grid_search.py output_results.tsv --output best_results.tsv --metric-col "success@5" --cuts 67.0 67.5 68.0 68.5 69.0 69.5 70 70.5 71
```

This script processes the grid search results and selects the configuration with minimal query time for each metric value threshold, helping identify optimal parameter trade-offs.

---

### IGP

**Official repository:** [https://github.com/DBGroup-SUSTech/multi-vector-retrieval](https://github.com/DBGroup-SUSTech/multi-vector-retrieval)

**Pre-built indexes and data:** [SharePoint Link](https://connectpolyu-my.sharepoint.com/:f:/g/personal/21041743r_connect_polyu_hk/ElyiRI2Y0FNPmoP0ecApAUwB3v3gL_aNSHZaIrifCV_jDA) (also available in the official IGP repository README)

**Detailed reproduction guide:** See [`competitors/igp/REPRODUCTION_GUIDE.md`](competitors/igp/REPRODUCTION_GUIDE.md) for complete step-by-step instructions.

To reproduce IGP experiments:

1. **Setup** (detailed in the reproduction guide):
   - Clone the IGP repository
   - Install system dependencies (Eigen, OpenBLAS, spdlog)
   - Build the IGP C++ module
   - Download pre-built indexes and embeddings

2. **Configure paths**: Edit the config files in `competitors/igp/config/` to point to your data location:
   ```bash
   # Edit data_root in both configs
   vim competitors/igp/config/msmarco.json
   vim competitors/igp/config/lotte.json
   ```

3. **Run grid search experiments**:
   ```bash
   # From the IGP repository directory
   python scripts/grid_search.py --config /path/to/this/repo/competitors/igp/config/msmarco.json
   python scripts/grid_search.py --config /path/to/this/repo/competitors/igp/config/lotte.json
   ```

4. **Extract best results** (fastest configuration per metric threshold):
   ```bash
   python scripts/extract_best_results.py --config /path/to/this/repo/competitors/igp/config/msmarco.json
   python scripts/extract_best_results.py --config /path/to/this/repo/competitors/igp/config/lotte.json
   ```

The grid search explores combinations of:
- **nprobe**: 1, 2, 4, 8, 16, 32, 64 (number of clusters to probe)
- **probe_topk**: 10, 20, 50, 100, 200, 300, 400, 500, 600 (candidates per cluster)

Results are saved as TSV files with query times and metrics (MRR@10 for MS MARCO, Success@5 for LoTTE).

---

### WARP

**Official repository:** [https://github.com/jlscheerer/xtr-warp](https://github.com/jlscheerer/xtr-warp)

**Pre-built indexes:** Available on Hugging Face:
- MS MARCO: [AnonymousUser2026/warp_ms_marco](https://huggingface.co/datasets/AnonymousUser2026/warp_ms_marco)
- LoTTE: [AnonymousUser2026/warp_lotte_pooled](https://huggingface.co/datasets/AnonymousUser2026/warp_lotte_pooled)

**Detailed reproduction guide:** See [`competitors/warp/REPRODUCTION_GUIDE.md`](competitors/warp/REPRODUCTION_GUIDE.md) for complete step-by-step instructions.

To reproduce WARP experiments:

1. **Setup** (detailed in the reproduction guide):
   - Clone the WARP repository
   - Install dependencies (conda environment provided)
   - Download pre-built indexes from Hugging Face

2. **Configure paths**: Edit `competitors/warp/run_grid_search.sh` to point to your data:
   ```bash
   LOTTE_BASE="/path/to/lotte"
   MSMARCO_BASE="/path/to/ms_marco"
   ```

3. **Run grid search**:
   ```bash
   # From the WARP repository directory, using scripts from this repo
   ./path/to/this/repo/competitors/warp/run_grid_search.sh
   ```

4. **Extract best results**:
   ```bash
   python extract_best_warp_results.py --input results/msmarco_grid_search_full.json --output results/msmarco_best_results.tsv --metric "MRR@10" --cuts 0.39 0.392 0.394 0.396 0.398 0.399 0.4 0.402
   python extract_best_warp_results.py --input results/lotte_grid_search_full.json --output results/lotte_best_results.tsv --metric "Success@5" --cuts 0.67 0.675 0.68 0.685 0.69 0.695 0.70 0.705
   ```

The grid search evaluates different `ncells` values (number of centroid lists to probe) to find the optimal speed/accuracy trade-off.




