#!/bin/bash

# Grid Search for Reranking Hyperparameters
# ===========================================
# This script performs a grid search over reranking hyperparameters as specified in the paper:
# - κ (k_candidates): {15, 20, 25, 30, 35, 40, 50}
# - α (alpha): {0.015, 0.025, 0.050, off}
# - β (beta): {2, 3, 4, off}
# Where "off" means the optimization (CP or EE) is disabled.

set -e  # Exit on error

# Default values
BASE_CONFIG=""
OUTPUT_DIR="grid_search_results"
TEMP_CONFIG="/tmp/grid_search_config_$$.toml"
PYTHON_SCRIPT="$(dirname "$0")/run_experiments.py"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Usage function
usage() {
    cat << EOF
Usage: $0 -c <base_config.toml> [-o <output_dir>] [-k <k_candidates>] [-a <alphas>] [-b <betas>]

Perform grid search over reranking hyperparameters.

Required arguments:
    -c <file>       Base TOML configuration file

Optional arguments:
    -o <dir>        Output directory for results (default: grid_search_results)
    -k <values>     Comma-separated k_candidates values (default: 15,20,25,30,35,40,50)
    -a <values>     Comma-separated alpha values, use 'off' to disable (default: 0.015,0.025,0.050,off)
    -b <values>     Comma-separated beta values, use 'off' to disable (default: 2,3,4,off)
    -h              Show this help message

Example:
    $0 -c experiments/multivec_rerank/rerank_plain_msmarco.toml
    $0 -c experiments/multivec_rerank/rerank_plain_msmarco.toml -k 15,25,50 -a 0.025,off

Paper defaults (from ECIR 2025):
    κ ∈ {15, 20, 25, 30, 35, 40, 50}
    α ∈ {0.015, 0.025, 0.050, off}  (Candidate Pruning)
    β ∈ {2, 3, 4, off}               (Early Exit)

EOF
    exit 1
}

# Default parameter values from the paper
K_CANDIDATES="15, 20, 25, 30, 35, 40, 50"
ALPHAS="0.015, 0.025, 0.050, off"
BETAS="2, 3, 4, off"

# Parse command line arguments
while getopts "c:o:k:a:b:h" opt; do
    case $opt in
        c) BASE_CONFIG="$OPTARG" ;;
        o) OUTPUT_DIR="$OPTARG" ;;
        k) K_CANDIDATES="$OPTARG" ;;
        a) ALPHAS="$OPTARG" ;;
        b) BETAS="$OPTARG" ;;
        h) usage ;;
        *) usage ;;
    esac
done

# Validate required arguments
if [ -z "$BASE_CONFIG" ]; then
    echo -e "${RED}Error: Base configuration file is required${NC}"
    usage
fi

if [ ! -f "$BASE_CONFIG" ]; then
    echo -e "${RED}Error: Configuration file not found: $BASE_CONFIG${NC}"
    exit 1
fi

if [ ! -f "$PYTHON_SCRIPT" ]; then
    echo -e "${RED}Error: run_experiments.py not found at: $PYTHON_SCRIPT${NC}"
    exit 1
fi

# Convert comma-separated values to arrays
IFS=',' read -ra K_ARRAY <<< "$K_CANDIDATES"
IFS=',' read -ra ALPHA_ARRAY <<< "$ALPHAS"
IFS=',' read -ra BETA_ARRAY <<< "$BETAS"

# Trim whitespace from array elements
for i in "${!K_ARRAY[@]}"; do
    K_ARRAY[$i]=$(echo "${K_ARRAY[$i]}" | xargs)
done
for i in "${!ALPHA_ARRAY[@]}"; do
    ALPHA_ARRAY[$i]=$(echo "${ALPHA_ARRAY[$i]}" | xargs)
done
for i in "${!BETA_ARRAY[@]}"; do
    BETA_ARRAY[$i]=$(echo "${BETA_ARRAY[$i]}" | xargs)
done

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Calculate total combinations
TOTAL_COMBINATIONS=$((${#K_ARRAY[@]} * ${#ALPHA_ARRAY[@]} * ${#BETA_ARRAY[@]}))

echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}Reranking Hyperparameter Grid Search${NC}"
echo -e "${GREEN}============================================${NC}"
echo -e "Base config:       ${BLUE}$BASE_CONFIG${NC}"
echo -e "Output directory:  ${BLUE}$OUTPUT_DIR${NC}"
echo -e "k_candidates:      ${BLUE}${K_CANDIDATES}${NC}"
echo -e "alphas:            ${BLUE}${ALPHAS}${NC}"
echo -e "betas:             ${BLUE}${BETAS}${NC}"
echo -e "Total combinations: ${YELLOW}$TOTAL_COMBINATIONS${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""

# Function to modify TOML file
modify_toml() {
    local config_file=$1
    local k_cand=$2
    local alpha=$3
    local beta=$4
    local output_file=$5
    
    # Copy base config
    cp "$config_file" "$output_file"
    
    # Modify k_candidates
    if grep -q "^k_candidates" "$output_file"; then
        sed -i "s/^k_candidates\s*=.*/k_candidates = $k_cand/" "$output_file"
    elif grep -q "^\[reranking\]" "$output_file"; then
        # Add k_candidates under [reranking] section if it doesn't exist
        sed -i "/^\[reranking\]/a k_candidates = $k_cand" "$output_file"
    fi
    
    # Modify alpha (or remove if "off")
    if [ "$alpha" = "off" ]; then
        # Comment out or remove alpha line
        sed -i '/^alpha\s*=/d' "$output_file"
    else
        if grep -q "^alpha" "$output_file"; then
            sed -i "s/^alpha\s*=.*/alpha = $alpha/" "$output_file"
        elif grep -q "^\[reranking\]" "$output_file"; then
            sed -i "/^\[reranking\]/a alpha = $alpha" "$output_file"
        fi
    fi
    
    # Modify beta (or remove if "off")
    if [ "$beta" = "off" ]; then
        # Comment out or remove beta line
        sed -i '/^beta\s*=/d' "$output_file"
    else
        if grep -q "^beta" "$output_file"; then
            sed -i "s/^beta\s*=.*/beta = $beta/" "$output_file"
        elif grep -q "^\[reranking\]" "$output_file"; then
            sed -i "/^\[reranking\]/a beta = $beta" "$output_file"
        fi
    fi
    
    # Modify experiment name to include parameters
    local exp_name="grid_search_k${k_cand}_a${alpha}_b${beta}"
    if grep -q "^name\s*=" "$output_file"; then
        sed -i "s/^name\s*=.*/name = \"$exp_name\"/" "$output_file"
    fi
    
    # Modify output folder to use our grid search directory
    if grep -q "^experiment\s*=" "$output_file"; then
        sed -i "s|^experiment\s*=.*|experiment = \"$OUTPUT_DIR\"|" "$output_file"
    fi
}

# Trap to clean up temp file on exit
trap "rm -f $TEMP_CONFIG" EXIT

# Counter for progress
COUNTER=0

# Summary file with detailed results
SUMMARY_FILE="$OUTPUT_DIR/grid_search_summary.tsv"
echo -e "k_candidates\talpha\tbeta\tef_search\tquery_time_us\tmetric_value" > "$SUMMARY_FILE"

# Main grid search loop
for k in "${K_ARRAY[@]}"; do
    for alpha in "${ALPHA_ARRAY[@]}"; do
        for beta in "${BETA_ARRAY[@]}"; do
            COUNTER=$((COUNTER + 1))
            
            echo -e "${YELLOW}[${COUNTER}/${TOTAL_COMBINATIONS}]${NC} Running: k=${GREEN}${k}${NC}, α=${GREEN}${alpha}${NC}, β=${GREEN}${beta}${NC}"
            
            # Create modified config
            modify_toml "$BASE_CONFIG" "$k" "$alpha" "$beta" "$TEMP_CONFIG"
            
            # Run experiment
            START_TIME=$(date +%s)
            
            if python3 "$PYTHON_SCRIPT" --exp "$TEMP_CONFIG"; then
                STATUS="SUCCESS"
                echo -e "${GREEN}✓ Completed successfully${NC}"
            else
                STATUS="FAILED"
                echo -e "${RED}✗ Failed${NC}"
            fi
            
            END_TIME=$(date +%s)
            ELAPSED=$((END_TIME - START_TIME))
            
            # Find the most recent experiment directory (run_experiments.py creates timestamped dirs)
            LATEST_EXP=$(ls -td "$OUTPUT_DIR"/grid_search_k${k}_a${alpha}_b${beta}_* 2>/dev/null | head -1 || echo "N/A")
            
            # Parse report.tsv and add detailed results to summary
            if [ "$STATUS" = "SUCCESS" ] && [ -f "$LATEST_EXP/report.tsv" ]; then
                # Skip the header line and parse each result line
                tail -n +2 "$LATEST_EXP/report.tsv" | while IFS=$'\t' read -r subsection query_time accuracy metric_value memory_usage building_time; do
                    # Extract ef_search value from subsection name (e.g., "efs_50" -> "50")
                    ef_search=$(echo "$subsection" | sed 's/efs_//')
                    
                    # Write detailed line to summary (excluding accuracy)
                    echo -e "${k}\t${alpha}\t${beta}\t${ef_search}\t${query_time}\t${metric_value}"
                done >> "$SUMMARY_FILE"
            fi
            
            echo ""
        done
    done
done

echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}Grid Search Complete!${NC}"
echo -e "${GREEN}============================================${NC}"
echo -e "Total experiments: ${YELLOW}${TOTAL_COMBINATIONS}${NC}"
echo -e "Results saved to: ${BLUE}${OUTPUT_DIR}${NC}"
echo -e "Summary file: ${BLUE}${SUMMARY_FILE}${NC}"
echo ""
echo -e "To analyze results, check individual experiment folders or run:"
echo -e "  ${BLUE}python scripts/extract_best_results.py${NC}"
echo -e "${GREEN}============================================${NC}"
