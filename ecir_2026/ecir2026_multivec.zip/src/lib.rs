#![feature(iter_array_chunks)]
#![cfg_attr(target_arch = "x86_64", feature(stdarch_x86_mm_shuffle))]
#![feature(portable_simd)]
#![feature(thread_id_value)]

pub mod topk_selectors;

use pyo3::types::PyModuleMethods;

pub mod pylib;
use crate::pylib::DensePQHNSW as DensePQIndexPy;
use crate::pylib::DensePlainHNSW as DensePlainIndexPy;
use crate::pylib::DensePlainHNSWf16 as DensePlainIndexPyf16;
use crate::pylib::SparsePlainHNSW as SparsePlainIndexPy;
use crate::pylib::SparsePlainHNSWf16 as SparsePlainIndexPyf16;
use num_traits::{ToPrimitive, Zero};
use pyo3::prelude::PyModule;
use pyo3::{pymodule, Bound, PyResult};

pub mod clustering {
    pub mod kmeans;
    pub use kmeans::KMeans;
    pub use kmeans::KMeansBuilder;
}

pub mod graph;

pub mod quantizers;
pub use quantizers::decoder;
pub use quantizers::encoder;
pub use quantizers::multivector_plain_quantizer;
pub use quantizers::multivector_product_quantizer;
pub use quantizers::plain_quantizer;
pub use quantizers::pq;
pub use quantizers::quantizer;
pub use quantizers::sparse_plain_quantizer;
pub mod visited_set;

pub mod datasets {
    pub mod dataset;
    pub mod dense_dataset;
    pub mod multivector_dataset;
    pub mod sparse_dataset;
    pub mod utils;
}

pub use datasets::dataset::Dataset;
pub use datasets::dataset::GrowableDataset;
pub use datasets::dense_dataset::DenseDataset;
pub use datasets::dense_dataset::DenseDatasetIter;
pub use datasets::multivector_dataset::MultiVectorDataset;
pub use datasets::sparse_dataset::ParSparseDatasetIter;
pub use datasets::sparse_dataset::SparseDataset;
pub use datasets::sparse_dataset::SparseDatasetIter;
pub use datasets::utils::*;

type PlainDenseDataset<T> = DenseDataset<plain_quantizer::PlainQuantizer<T>>;

pub mod distances;
pub use distances::dot_product::*;
pub use distances::euclidean_distance::*;
pub use distances::multivector::*;
pub use distances::simd::distances as simd_distances;
pub use distances::simd::transpose as simd_transpose;
pub use distances::simd::utils as simd_utils;

pub mod utils;

pub mod indexes;
pub use indexes::{graph_index, hnsw, hnsw_utils, rerank_index};

pub mod index_serializer;
pub use index_serializer::IndexSerializer;

use half::f16;

use serde::{Deserialize, Serialize};

#[derive(Default, Debug, Copy, Clone, Serialize, Deserialize, PartialEq)]
pub enum DistanceType {
    #[default]
    Euclidean,
    DotProduct,
}

pub trait Float: Copy + Default + ToPrimitive + PartialOrd + Zero + Send + Sync {}

//impl Float for f64 {}
impl Float for f32 {}
impl Float for f16 {}

/// A trait for a 1D array, that contains elements of type `Item`.
pub trait AsRefItem {
    type Item;

    fn as_ref_item(&self) -> &[Self::Item];
}

impl<U> AsRefItem for Vec<U> {
    type Item = U;

    #[inline(always)]
    fn as_ref_item(&self) -> &[Self::Item] {
        self.as_slice()
    }
}

impl<U> AsRefItem for Box<[U]> {
    type Item = U;

    #[inline(always)]
    fn as_ref_item(&self) -> &[Self::Item] {
        self.as_ref()
    }
}

impl<U> AsRefItem for &[U] {
    type Item = U;

    #[inline(always)]
    fn as_ref_item(&self) -> &[Self::Item] {
        self
    }
}

impl<U> AsRefItem for &mut [U] {
    type Item = U;

    #[inline(always)]
    fn as_ref_item(&self) -> &[Self::Item] {
        self
    }
}

pub trait VectorType {
    type ComponentsType;
    type ValuesType;

    fn len(&self) -> usize;
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
    fn components_as_slice(&self) -> &[Self::ComponentsType];
    fn values_as_slice(&self) -> &[Self::ValuesType];
}

static EMPTY_COMPONENTS: [(); 0] = [];

#[derive(Debug, Clone, PartialEq)]
pub struct DenseVector1D<T: AsRefItem> {
    components: (),
    values: T,
}

impl<T: AsRefItem> DenseVector1D<T> {
    #[inline]
    pub fn new(values: T) -> Self {
        DenseVector1D {
            components: (),
            values,
        }
    }
}

impl<T: AsRefItem> VectorType for DenseVector1D<T> {
    type ComponentsType = ();
    type ValuesType = T::Item;

    #[inline(always)]
    fn len(&self) -> usize {
        self.values.as_ref_item().len()
    }

    #[inline(always)]
    fn components_as_slice(&self) -> &[Self::ComponentsType] {
        &EMPTY_COMPONENTS
    }

    #[inline(always)]
    fn values_as_slice(&self) -> &[Self::ValuesType] {
        self.values.as_ref_item()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct SparseVector1D<V, T>
where
    V: AsRefItem<Item = u16>,
    T: AsRefItem,
{
    components: V,
    values: T,
    max_component_id: u16,
    d: usize, // dimensionality of the vector space
}

impl<V, T> SparseVector1D<V, T>
where
    V: AsRefItem<Item = u16>,
    T: AsRefItem,
{
    #[inline]
    pub fn new(components: V, values: T, d: usize) -> Self {
        let max_component_id = components.as_ref_item().iter().max().copied().unwrap_or(0);
        SparseVector1D {
            components,
            values,
            max_component_id,
            d,
        }
    }
}

impl<V, T> VectorType for SparseVector1D<V, T>
where
    V: AsRefItem<Item = u16>,
    T: AsRefItem,
{
    type ComponentsType = V::Item;
    type ValuesType = T::Item;

    /// Returns the length of the sparse array.
    ///
    /// The length is defined as the value of the highest component index plus one.
    /// This length is precomputed during initialization and stored in the `max_component` field.
    /// Therefore, this method provides an O(1) access time.
    ///
    /// The length is computed as the maximum component index plus one because the components
    /// represent indices that are zero-based. Therefore, if the highest index in the components
    /// is `n`, the total length of the array must be `n + 1` to account for the zero index.
    ///
    /// # Returns
    ///
    /// The length of the array, which is the maximum component index plus one.
    ///
    #[inline(always)]
    fn len(&self) -> usize {
        (self.max_component_id as usize) + 1
    }

    #[inline(always)]
    fn components_as_slice(&self) -> &[Self::ComponentsType] {
        self.components.as_ref_item()
    }

    #[inline(always)]
    fn values_as_slice(&self) -> &[Self::ValuesType] {
        self.values.as_ref_item()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct MultiVector<T: AsRefItem> {
    components: (), // Empty for dense multivectors
    values: T,
    num_vectors: usize,
    vector_dim: usize,
}

impl<T: AsRefItem> MultiVector<T> {
    #[inline]
    pub fn new(values: T, num_vectors: usize, vector_dim: usize) -> Self {
        debug_assert_eq!(
            values.as_ref_item().len(),
            num_vectors * vector_dim,
            "Values length must equal num_vectors * vector_dim"
        );

        MultiVector {
            components: (),
            values,
            num_vectors,
            vector_dim,
        }
    }

    #[inline]
    pub fn num_vectors(&self) -> usize {
        self.num_vectors
    }

    #[inline]
    pub fn vector_dim(&self) -> usize {
        self.vector_dim
    }

    #[inline]
    pub fn get_vector(&self, index: usize) -> &[T::Item] {
        debug_assert!(index < self.num_vectors, "Vector index out of bounds");
        let start = index * self.vector_dim;
        let end = start + self.vector_dim;
        &self.values.as_ref_item()[start..end]
    }

    #[inline]
    pub fn iter_vectors(&self) -> impl Iterator<Item = &[T::Item]> + '_ {
        (0..self.num_vectors).map(move |i| self.get_vector(i))
    }
}

impl<T: AsRefItem> VectorType for MultiVector<T> {
    type ComponentsType = ();
    type ValuesType = T::Item;

    #[inline(always)]
    fn len(&self) -> usize {
        // Total number of elements across all vectors
        self.values.as_ref_item().len()
    }

    #[inline(always)]
    fn components_as_slice(&self) -> &[Self::ComponentsType] {
        &EMPTY_COMPONENTS
    }

    #[inline(always)]
    fn values_as_slice(&self) -> &[Self::ValuesType] {
        self.values.as_ref_item()
    }
}

use rayon::prelude::*;
use std::cell::RefCell;

#[cfg(feature = "use-libxsmm")]
use libc::c_void;

#[cfg(feature = "use-libxsmm")]
mod libxsmm_bindings;

// Thread-local buffers to avoid repeated allocations
thread_local! {
    static SIMILARITY_BUFFER: RefCell<Vec<f32>> = RefCell::new(Vec::new());
    static TEMP_BUFFER: RefCell<Vec<f32>> = RefCell::new(Vec::new());
    static BATCH_BUFFER: RefCell<Vec<f32>> = RefCell::new(Vec::with_capacity(1024 * 1024));
}

// Initialize libxsmm only once
#[cfg(feature = "use-libxsmm")]
use std::sync::Once;

#[cfg(feature = "use-libxsmm")]
static LIBXSMM_INIT: Once = Once::new();

// SIMD module with platform-specific implementations.
// TODO: AVX512?
mod simd {
    #[cfg(target_arch = "x86_64")]
    use std::arch::x86_64::*;

    #[cfg(target_arch = "aarch64")]
    use std::arch::aarch64::*;

    /// Find max w/ AVX2 and prefetching.
    #[cfg(target_arch = "x86_64")]
    #[inline]
    pub fn simd_max_avx2(slice: &[f32]) -> f32 {
        if slice.len() < 8 {
            return slice.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        }

        unsafe {
            // Use 4 vectors for better ILP (Instruction Level Parallelism)
            let mut max_vec0 = _mm256_set1_ps(f32::NEG_INFINITY);
            let mut max_vec1 = _mm256_set1_ps(f32::NEG_INFINITY);
            let mut max_vec2 = _mm256_set1_ps(f32::NEG_INFINITY);
            let mut max_vec3 = _mm256_set1_ps(f32::NEG_INFINITY);

            let mut i = 0;

            // Process 32 elements at a time (4x8) for better ILP
            while i + 32 <= slice.len() {
                // Prefetch next cache line
                _mm_prefetch(slice.as_ptr().add(i + 64) as *const i8, _MM_HINT_T0);

                let data0 = _mm256_loadu_ps(slice.as_ptr().add(i));
                let data1 = _mm256_loadu_ps(slice.as_ptr().add(i + 8));
                let data2 = _mm256_loadu_ps(slice.as_ptr().add(i + 16));
                let data3 = _mm256_loadu_ps(slice.as_ptr().add(i + 24));

                max_vec0 = _mm256_max_ps(max_vec0, data0);
                max_vec1 = _mm256_max_ps(max_vec1, data1);
                max_vec2 = _mm256_max_ps(max_vec2, data2);
                max_vec3 = _mm256_max_ps(max_vec3, data3);

                i += 32;
            }

            // Process remaining groups of 8
            while i + 8 <= slice.len() {
                let data = _mm256_loadu_ps(slice.as_ptr().add(i));
                max_vec0 = _mm256_max_ps(max_vec0, data);
                i += 8;
            }

            // Combine the 4 vectors
            max_vec0 = _mm256_max_ps(max_vec0, max_vec1);
            max_vec2 = _mm256_max_ps(max_vec2, max_vec3);
            max_vec0 = _mm256_max_ps(max_vec0, max_vec2);

            // Horizontal max within the final vector
            let high = _mm256_extractf128_ps(max_vec0, 1);
            let low = _mm256_castps256_ps128(max_vec0);
            let max128 = _mm_max_ps(high, low);

            let shuffled = _mm_shuffle_ps(max128, max128, 0b01001110);
            let max64 = _mm_max_ps(max128, shuffled);
            let shuffled2 = _mm_shuffle_ps(max64, max64, 0b00000001);
            let final_max = _mm_max_ps(max64, shuffled2);

            let mut result = _mm_cvtss_f32(final_max);

            // Handle remaining elements
            for j in i..slice.len() {
                result = result.max(slice[j]);
            }

            result
        }
    }

    /// Find max w/ ARM NEON.
    #[cfg(target_arch = "aarch64")]
    #[inline]
    pub fn simd_max_avx2(slice: &[f32]) -> f32 {
        if slice.len() < 4 {
            return slice.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        }

        unsafe {
            // Initialize 4 vectors for better ILP
            let mut max_vec0 = vdupq_n_f32(f32::NEG_INFINITY);
            let mut max_vec1 = vdupq_n_f32(f32::NEG_INFINITY);
            let mut max_vec2 = vdupq_n_f32(f32::NEG_INFINITY);
            let mut max_vec3 = vdupq_n_f32(f32::NEG_INFINITY);

            let mut i = 0;

            // Process 16 elements at a time (4x4)
            while i + 16 <= slice.len() {
                let data0 = vld1q_f32(slice.as_ptr().add(i));
                let data1 = vld1q_f32(slice.as_ptr().add(i + 4));
                let data2 = vld1q_f32(slice.as_ptr().add(i + 8));
                let data3 = vld1q_f32(slice.as_ptr().add(i + 12));

                max_vec0 = vmaxq_f32(max_vec0, data0);
                max_vec1 = vmaxq_f32(max_vec1, data1);
                max_vec2 = vmaxq_f32(max_vec2, data2);
                max_vec3 = vmaxq_f32(max_vec3, data3);

                i += 16;
            }

            // Process remaining groups of 4
            while i + 4 <= slice.len() {
                let data = vld1q_f32(slice.as_ptr().add(i));
                max_vec0 = vmaxq_f32(max_vec0, data);
                i += 4;
            }

            // Combine the 4 vectors
            max_vec0 = vmaxq_f32(max_vec0, max_vec1);
            max_vec2 = vmaxq_f32(max_vec2, max_vec3);
            max_vec0 = vmaxq_f32(max_vec0, max_vec2);

            // Horizontal max within the final vector
            let max_pair = vmaxq_f32(max_vec0, vextq_f32(max_vec0, max_vec0, 2));
            let max_val = vmaxq_f32(max_pair, vextq_f32(max_pair, max_pair, 1));
            let mut result = vgetq_lane_f32(max_val, 0);

            // Handle remaining elements
            for j in i..slice.len() {
                result = result.max(slice[j]);
            }

            result
        }
    }

    /// Fallback-ish. Really not great.
    #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
    #[inline]
    pub fn simd_max_avx2(slice: &[f32]) -> f32 {
        slice.iter().copied().fold(f32::NEG_INFINITY, f32::max)
    }
}

// MaxSim algorithm.
pub mod algorithm {
    use super::*;
    use crate::simd::simd_max_avx2;
    use blas::sgemm;

    /// Process a single variable-length document directly
    pub fn process_single_doc(
        q: &[f32],   // [q_len * dim]
        doc: &[f32], // [doc_len * dim]
        q_len: usize,
        doc_len: usize,
        dim: usize,
    ) -> f32 {
        // Use thread-local buffer to avoid allocations
        SIMILARITY_BUFFER.with(|buffer| {
            let mut buffer = buffer.borrow_mut();
            buffer.resize(q_len * doc_len, 0.0);

            // Compute Q × D^T
            unsafe {
                sgemm(
                    b'T',
                    b'N',
                    doc_len as i32,
                    q_len as i32,
                    dim as i32,
                    1.0,
                    doc,
                    dim as i32,
                    q,
                    dim as i32,
                    0.0,
                    buffer.as_mut_slice(),
                    doc_len as i32,
                );
            }

            // Find max for each query and sum
            let mut score = 0.0f32;
            for qi in 0..q_len {
                let start = qi * doc_len;
                let query_sims = &buffer[start..start + doc_len];
                score += simd_max_avx2(query_sims);
            }

            score
        })
    }

    /// Fused GEMM+reduction with document tiling
    pub fn maxsim_fused_doc_tiles(
        q: &[f32], // [q_len * dim]
        d: &[f32], // [n_docs * d_len * dim]
        q_len: usize,
        d_len: usize,
        dim: usize,
    ) -> Vec<f32> {
        let n_docs = d.len() / (d_len * dim);

        // For macOS/ARM, use more efficient processing strategy
        #[cfg(target_arch = "aarch64")]
        {
            // Process documents in parallel without excessive tiling
            // ARM has unified memory architecture, so tiling is not anywhere near as important.
            (0..n_docs)
                .into_par_iter()
                .map(|doc_idx| {
                    let doc_offset = doc_idx * d_len * dim;
                    let doc_data = &d[doc_offset..doc_offset + d_len * dim];

                    // Process in smaller blocks to fit in L2 cache
                    let block_size = 64; // Claude says this is the best value to fit in cache for most Apple chips.
                    let mut max_vals = vec![f32::NEG_INFINITY; q_len];

                    for block_start in (0..d_len).step_by(block_size) {
                        let block_end = (block_start + block_size).min(d_len);
                        let actual_block_size = block_end - block_start;

                        // Compute similarities for this block
                        let mut block_sims = vec![0.0f32; q_len * actual_block_size];
                        let block_data = &doc_data[block_start * dim..block_end * dim];

                        unsafe {
                            sgemm(
                                b'T',
                                b'N',
                                actual_block_size as i32,
                                q_len as i32,
                                dim as i32,
                                1.0,
                                block_data,
                                dim as i32,
                                q,
                                dim as i32,
                                0.0,
                                &mut block_sims,
                                actual_block_size as i32,
                            );
                        }

                        // Update max values using NEON
                        for qi in 0..q_len {
                            let base_idx = qi * actual_block_size;
                            let query_sims = &block_sims[base_idx..base_idx + actual_block_size];
                            let max_val = simd_max_avx2(query_sims);
                            max_vals[qi] = max_vals[qi].max(max_val);
                        }
                    }

                    // Sum max values
                    max_vals.iter().sum()
                })
                .collect()
        }

        #[cfg(not(target_arch = "aarch64"))]
        {
            let mut results = vec![0.0f32; n_docs];

            // x86 tiling strategy
            let doc_tile_size = match d_len {
                512 => 128,
                1024 => 64,
                2048 => 32,
                4096 => 16,
                _ => 32,
            };

            for doc_tile_start in (0..n_docs).step_by(doc_tile_size) {
                let doc_tile_end = (doc_tile_start + doc_tile_size).min(n_docs);
                let tile_docs = doc_tile_end - doc_tile_start;
                let tile_tokens = tile_docs * d_len;

                let mut tile_sims = vec![0.0f32; q_len * tile_tokens];
                let tile_d_start = doc_tile_start * d_len * dim;
                let tile_d_end = doc_tile_end * d_len * dim;
                let tile_d = &d[tile_d_start..tile_d_end];

                unsafe {
                    sgemm(
                        b'T',
                        b'N',
                        tile_tokens as i32,
                        q_len as i32,
                        dim as i32,
                        1.0,
                        tile_d,
                        dim as i32,
                        q,
                        dim as i32,
                        0.0,
                        &mut tile_sims,
                        tile_tokens as i32,
                    );
                }

                let tile_results: Vec<f32> = (0..tile_docs)
                    .into_par_iter()
                    .map(|tile_doc_idx| {
                        let doc_start = tile_doc_idx * d_len;
                        let mut score = 0.0f32;

                        for qi in 0..q_len {
                            let base_idx = doc_start + qi * tile_tokens;
                            let doc_sims = &tile_sims[base_idx..base_idx + d_len];
                            let max_val = simd_max_avx2(doc_sims);
                            score += max_val;
                        }

                        score
                    })
                    .collect();

                for (i, &score) in tile_results.iter().enumerate() {
                    results[doc_tile_start + i] = score;
                }
            }

            results
        }
    }

    pub fn maxsim_ultra_adaptive(
        q: &[f32], // [q_len * dim]
        d: &[f32], // [n_docs * d_len * dim]
        q_len: usize,
        d_len: usize,
        dim: usize,
    ) -> Vec<f32> {
        #[cfg(feature = "use-libxsmm")]
        {
            crate::libxsmm::maxsim_libxsmm_clean(q, d, q_len, d_len, dim)
        }

        #[cfg(not(feature = "use-libxsmm"))]
        {
            maxsim_fused_doc_tiles(q, d, q_len, d_len, dim)
        }
    }

    /// Process variable-length documents with optimized batching
    pub fn maxsim_variable_length(
        q: &[f32],                              // [q_len * dim]
        doc_infos: Vec<(usize, usize, &[f32])>, // [(doc_idx, doc_len, doc_data)]
        q_len: usize,
        dim: usize,
    ) -> Vec<f32> {
        #[cfg(feature = "use-libxsmm")]
        {
            return crate::libxsmm::maxsim_libxsmm_variable(q, doc_infos, q_len, dim);
        }

        #[cfg(not(feature = "use-libxsmm"))]
        {
            let n_docs = doc_infos.len();
            let mut results = vec![0.0f32; n_docs];

            // Fast path: if all documents have similar lengths, process in one batch
            let (min_len, max_len) = doc_infos
                .iter()
                .map(|(_, len, _)| *len)
                .fold((usize::MAX, 0), |(min, max), len| {
                    (min.min(len), max.max(len))
                });

            if max_len as f32 / min_len as f32 <= 1.2 && n_docs >= 50 {
                // All documents have similar lengths - process in single batch
                return BATCH_BUFFER.with(|buffer| {
                    let mut buffer = buffer.borrow_mut();
                    let required_size = n_docs * max_len * dim;
                    buffer.resize(required_size, 0.0);
                    buffer.fill(0.0);

                    // Fill all documents
                    for (idx, (_, doc_len, doc_data)) in doc_infos.iter().enumerate() {
                        let src_size = doc_len * dim;
                        let dst_offset = idx * max_len * dim;
                        buffer[dst_offset..dst_offset + src_size]
                            .copy_from_slice(&doc_data[..src_size]);
                    }

                    // Process all at once
                    let batch_results =
                        maxsim_fused_doc_tiles(q, &buffer[..required_size], q_len, max_len, dim);

                    // Results are already in correct order
                    let mut final_results = vec![0.0f32; n_docs];
                    for (idx, (doc_idx, _, _)) in doc_infos.iter().enumerate() {
                        final_results[*doc_idx] = batch_results[idx];
                    }
                    final_results
                });
            }

            // Sort documents by length for better batching
            let mut sorted_indices: Vec<usize> = (0..n_docs).collect();
            sorted_indices.sort_by_key(|&i| doc_infos[i].1);

            // Process in larger batches with adaptive sizing
            let target_batch_size = 128; // Larger batches for better GEMM efficiency
            let mut i = 0;

            while i < n_docs {
                // Find batch end - include docs within 20% length difference
                let base_len = doc_infos[sorted_indices[i]].1;
                let max_acceptable_len = (base_len as f32 * 1.2) as usize;

                let mut batch_end = i + 1;
                while batch_end < n_docs && batch_end < i + target_batch_size {
                    if doc_infos[sorted_indices[batch_end]].1 > max_acceptable_len {
                        break;
                    }
                    batch_end += 1;
                }

                let batch_size = batch_end - i;

                if batch_size == 1 {
                    // Single document
                    let idx = sorted_indices[i];
                    let (doc_idx, doc_len, doc_data) = &doc_infos[idx];
                    results[*doc_idx] = process_single_doc(q, doc_data, q_len, *doc_len, dim);
                } else if batch_size >= 32 {
                    // Large batch - worth the overhead of batched processing
                    // Check if all documents in batch have exactly the same length
                    let first_len = doc_infos[sorted_indices[i]].1;
                    let all_same_length = sorted_indices[i..batch_end]
                        .iter()
                        .all(|&idx| doc_infos[idx].1 == first_len);

                    if all_same_length {
                        // Super optimized path - no padding needed!
                        let batch_results = BATCH_BUFFER.with(|buffer| {
                            let mut buffer = buffer.borrow_mut();
                            let required_size = batch_size * first_len * dim;
                            buffer.resize(required_size, 0.0);

                            // Copy documents contiguously
                            for (batch_idx, &sorted_idx) in
                                sorted_indices[i..batch_end].iter().enumerate()
                            {
                                let (_, _, doc_data) = &doc_infos[sorted_idx];
                                let dst_offset = batch_idx * first_len * dim;
                                buffer[dst_offset..dst_offset + first_len * dim]
                                    .copy_from_slice(&doc_data[..first_len * dim]);
                            }

                            // Process with no wasted computation
                            maxsim_fused_doc_tiles(
                                q,
                                &buffer[..required_size],
                                q_len,
                                first_len,
                                dim,
                            )
                        });

                        // Copy results back
                        for (batch_idx, &sorted_idx) in
                            sorted_indices[i..batch_end].iter().enumerate()
                        {
                            let (doc_idx, _, _) = &doc_infos[sorted_idx];
                            results[*doc_idx] = batch_results[batch_idx];
                        }
                    } else {
                        // Batch processing with padding
                        let max_len = sorted_indices[i..batch_end]
                            .iter()
                            .map(|&idx| doc_infos[idx].1)
                            .max()
                            .unwrap();

                        let batch_results = BATCH_BUFFER.with(|buffer| {
                            let mut buffer = buffer.borrow_mut();
                            let required_size = batch_size * max_len * dim;

                            // Resize buffer if needed
                            buffer.resize(required_size, 0.0);

                            // Fill batch - only clear padding areas
                            for (batch_idx, &sorted_idx) in
                                sorted_indices[i..batch_end].iter().enumerate()
                            {
                                let (_, doc_len, doc_data) = &doc_infos[sorted_idx];
                                let src_size = doc_len * dim;
                                let dst_offset = batch_idx * max_len * dim;

                                // Copy actual data
                                buffer[dst_offset..dst_offset + src_size]
                                    .copy_from_slice(&doc_data[..src_size]);

                                // Clear only the padding area
                                if *doc_len < max_len {
                                    let padding_start = dst_offset + src_size;
                                    let padding_end = dst_offset + max_len * dim;
                                    buffer[padding_start..padding_end].fill(0.0);
                                }
                            }

                            // Process batch with optimized kernel
                            maxsim_fused_doc_tiles(q, &buffer[..required_size], q_len, max_len, dim)
                        });

                        // Copy results back to original positions
                        for (batch_idx, &sorted_idx) in
                            sorted_indices[i..batch_end].iter().enumerate()
                        {
                            let (doc_idx, _, _) = &doc_infos[sorted_idx];
                            results[*doc_idx] = batch_results[batch_idx];
                        }
                    }
                } else {
                    // Small batch - process with standard approach
                    // Batch processing with reused buffer
                    let max_len = sorted_indices[i..batch_end]
                        .iter()
                        .map(|&idx| doc_infos[idx].1)
                        .max()
                        .unwrap();

                    let batch_results = BATCH_BUFFER.with(|buffer| {
                        let mut buffer = buffer.borrow_mut();
                        let required_size = batch_size * max_len * dim;

                        // Resize buffer if needed
                        buffer.resize(required_size, 0.0);

                        // Fill batch - only clear padding areas
                        for (batch_idx, &sorted_idx) in
                            sorted_indices[i..batch_end].iter().enumerate()
                        {
                            let (_, doc_len, doc_data) = &doc_infos[sorted_idx];
                            let src_size = doc_len * dim;
                            let dst_offset = batch_idx * max_len * dim;

                            // Copy actual data
                            buffer[dst_offset..dst_offset + src_size]
                                .copy_from_slice(&doc_data[..src_size]);

                            // Clear only the padding area
                            if *doc_len < max_len {
                                let padding_start = dst_offset + src_size;
                                let padding_end = dst_offset + max_len * dim;
                                buffer[padding_start..padding_end].fill(0.0);
                            }
                        }

                        // Process batch with optimized kernel
                        maxsim_fused_doc_tiles(q, &buffer[..required_size], q_len, max_len, dim)
                    });

                    // Copy results back to original positions
                    for (batch_idx, &sorted_idx) in sorted_indices[i..batch_end].iter().enumerate()
                    {
                        let (doc_idx, _, _) = &doc_infos[sorted_idx];
                        results[*doc_idx] = batch_results[batch_idx];
                    }
                }

                i = batch_end;
            }

            results
        }
    }
}

/// A Python module implemented in Rust. The name of this function must match the `lib.name`
/// setting in the `Cargo.toml`, otherwise Python will not be able to import the module.
#[pymodule]
pub fn kannolo(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<DensePlainIndexPy>()?;
    m.add_class::<DensePlainIndexPyf16>()?;
    m.add_class::<SparsePlainIndexPy>()?;
    m.add_class::<SparsePlainIndexPyf16>()?;
    m.add_class::<DensePQIndexPy>()?;
    Ok(())
}
