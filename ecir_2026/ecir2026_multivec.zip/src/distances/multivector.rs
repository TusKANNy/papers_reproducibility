use crate::distances::dot_product_batch_4_simd;
use crate::distances::dot_product_simd;
use crate::{Float, MultiVector, VectorType};

/// Computes MaxSim between two multivectors.
/// MaxSim is the sum over query vectors of the maximum dot product
/// with any document vector.
#[inline]
pub fn multivector_maxsim<T: Float>(
    multivec1: &MultiVector<&[T]>,
    multivec2: &MultiVector<&[T]>,
) -> f32
where
    T: crate::DotProduct<T>,
{
    multivector_maxsim_query(multivec1, multivec2)
}

/// Computes MaxSim between a query multivector and a document multivector.
/// For each vector in the query, finds the maximum dot product with any vector in the document.
/// This is the ORIGINAL implementation.
#[inline]
pub fn multivector_maxsim_query<T: Float>(
    query: &MultiVector<&[T]>,
    document: &MultiVector<&[T]>,
) -> f32
where
    T: crate::DotProduct<T>,
{
    let mut total_sim = 0.0f32;

    // For each query vector
    for query_vec in query.iter_vectors() {
        let mut max_sim = f32::NEG_INFINITY;

        // Find maximum similarity with any document vector
        for doc_vec in document.iter_vectors() {
            let sim = dot_product_simd(query_vec, doc_vec);
            if sim > max_sim {
                max_sim = sim;
            }
        }

        total_sim += max_sim;
    }

    total_sim
}

/// Computes MaxSim between a query multivector and a document multivector using batched dot products (batch size 4).
/// For each query vector, finds the maximum dot product with any vector in the document, using SIMD batch processing.
pub fn multivector_maxsim_query_batch_4<T: Float>(
    query: &MultiVector<&[T]>,
    document: &MultiVector<&[T]>,
) -> f32
where
    T: crate::DotProduct<T>,
{
    let mut total_sim = 0.0f32;

    let doc_vecs: Vec<&[T]> = document.iter_vectors().collect();
    for query_vec in query.iter_vectors() {
        let mut max_sim = f32::NEG_INFINITY;
        let mut doc_iter = doc_vecs.iter().copied();
        for batch in doc_iter.by_ref().array_chunks::<4>() {
            let sims = dot_product_batch_4_simd(query_vec, batch);

            // Extract max
            let a = sims[0].max(sims[1]);
            let b = sims[2].max(sims[3]);
            let local = a.max(b);
            max_sim = max_sim.max(local);
        }

        for doc_vec in doc_iter {
            let sim = crate::distances::dot_product_simd(query_vec, doc_vec);
            max_sim = max_sim.max(sim);
        }

        total_sim += max_sim;
    }
    total_sim
}

/// NEW OPTIMIZED: MaxSim computation for f32 slices using the optimized algorithm
/// Assumes dimensions are already validated and lengths pre-computed
pub fn multivector_maxsim_slices_optimized(
    query_flat: &[f32], // Flat query data [q_len * dim]
    doc_flat: &[f32],   // Flat document data [d_len * dim]
    q_len: usize,       // Number of query vectors (pre-computed)
    d_len: usize,       // Number of document vectors
    dim: usize,         // Vector dimension
) -> f32 {
    // Use the optimized maxsim algorithm for single document
    crate::algorithm::process_single_doc(query_flat, doc_flat, q_len, d_len, dim)
}

/// NEW OPTIMIZED: MaxSim computation for f32 multivectors using the optimized algorithm
pub fn multivector_maxsim_query_optimized(
    query: &MultiVector<&[f32]>,
    document: &MultiVector<&[f32]>,
) -> f32 {
    let q_len = query.num_vectors();
    let d_len = document.num_vectors();
    let dim = query.vector_dim();

    // Ensure dimensions match
    if dim != document.vector_dim() {
        panic!("Query and document vector dimensions must match");
    }

    // Get flat slices of the data
    let query_flat = query.values_as_slice();
    let doc_flat = document.values_as_slice();

    // Use the optimized slice function
    multivector_maxsim_slices_optimized(query_flat, doc_flat, q_len, d_len, dim)
}
